<?php
if (!defined('ABSPATH')) exit;

// Debug function
function woodash_debug_log($message) {
    $log_file = WP_CONTENT_DIR . '/woodash-debug.log';
    $timestamp = date('[Y-m-d H:i:s] ');
    file_put_contents($log_file, $timestamp . $message . "\n", FILE_APPEND);
}

/**
 * WooDash Pro API Endpoints
 * Comprehensive backend API for orders, customers, products, and analytics
 */

// Orders Management Endpoints
add_action('wp_ajax_woodash_get_orders', 'woodash_get_orders');
add_action('wp_ajax_woodash_create_order', 'woodash_create_order');
add_action('wp_ajax_woodash_update_order', 'woodash_update_order');
add_action('wp_ajax_woodash_delete_order', 'woodash_delete_order');
add_action('wp_ajax_woodash_get_order_details', 'woodash_get_order_details');

// Customer Management Endpoints
add_action('wp_ajax_woodash_get_customers', 'woodash_get_customers');
add_action('wp_ajax_woodash_create_customer', 'woodash_create_customer');

// Product Management Endpoints
add_action('wp_ajax_woodash_get_products', 'woodash_get_products');
add_action('wp_ajax_woodash_search_products', 'woodash_search_products');
add_action('wp_ajax_woodash_create_product', 'woodash_create_product');
add_action('wp_ajax_woodash_update_product', 'woodash_update_product');
add_action('wp_ajax_woodash_delete_product', 'woodash_delete_product');
add_action('wp_ajax_woodash_get_product_stats', 'woodash_get_product_stats');

// Dashboard Analytics Endpoints
add_action('wp_ajax_woodash_get_dashboard_stats', 'woodash_get_dashboard_stats');
add_action('wp_ajax_woodash_get_analytics_data', 'woodash_get_analytics_data');

// Extended Customer Management Endpoints
add_action('wp_ajax_woodash_get_customer_details', 'woodash_get_customer_details');
add_action('wp_ajax_woodash_update_customer', 'woodash_update_customer');
add_action('wp_ajax_woodash_delete_customer', 'woodash_delete_customer');
add_action('wp_ajax_woodash_get_customer_orders', 'woodash_get_customer_orders');
add_action('wp_ajax_woodash_get_customer_stats', 'woodash_get_customer_stats');

// Reports & Analytics Endpoints
add_action('wp_ajax_woodash_get_sales_report', 'woodash_get_sales_report');
add_action('wp_ajax_woodash_get_product_report', 'woodash_get_product_report');
add_action('wp_ajax_woodash_get_customer_report', 'woodash_get_customer_report');
add_action('wp_ajax_woodash_get_revenue_analytics', 'woodash_get_revenue_analytics');

// Stock Management Endpoints
add_action('wp_ajax_woodash_get_stock_data', 'woodash_get_stock_data');
add_action('wp_ajax_woodash_update_stock', 'woodash_update_stock');
add_action('wp_ajax_woodash_get_low_stock_products', 'woodash_get_low_stock_products');
add_action('wp_ajax_woodash_get_stock_movements', 'woodash_get_stock_movements');

// Reviews Management Endpoints
add_action('wp_ajax_woodash_get_reviews', 'woodash_get_reviews');
add_action('wp_ajax_woodash_update_review_status', 'woodash_update_review_status');
add_action('wp_ajax_woodash_delete_review', 'woodash_delete_review');
add_action('wp_ajax_woodash_get_review_stats', 'woodash_get_review_stats');

// Marketing & Campaigns Endpoints
add_action('wp_ajax_woodash_get_campaigns', 'woodash_get_campaigns');
add_action('wp_ajax_woodash_create_campaign', 'woodash_create_campaign');
add_action('wp_ajax_woodash_update_campaign', 'woodash_update_campaign');
add_action('wp_ajax_woodash_delete_campaign', 'woodash_delete_campaign');
add_action('wp_ajax_woodash_get_marketing_stats', 'woodash_get_marketing_stats');

// Settings Management Endpoints
add_action('wp_ajax_woodash_get_settings', 'woodash_get_settings');
add_action('wp_ajax_woodash_update_settings', 'woodash_update_settings');
add_action('wp_ajax_woodash_reset_settings', 'woodash_reset_settings');

/**
 * Get orders with pagination and filtering
 */
function woodash_get_orders() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $per_page = isset($_POST['per_page']) ? intval($_POST['per_page']) : 20;
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        
        $args = array(
            'type' => 'shop_order',
            'limit' => $per_page,
            'offset' => ($page - 1) * $per_page,
            'orderby' => 'date',
            'order' => 'DESC',
        );
        
        if ($status) {
            $args['status'] = array('wc-' . $status);
        }
        
        if ($search) {
            $args['meta_query'] = array(
                'relation' => 'OR',
                array(
                    'key' => '_billing_first_name',
                    'value' => $search,
                    'compare' => 'LIKE'
                ),
                array(
                    'key' => '_billing_last_name',
                    'value' => $search,
                    'compare' => 'LIKE'
                ),
                array(
                    'key' => '_billing_email',
                    'value' => $search,
                    'compare' => 'LIKE'
                )
            );
        }
        
        $orders = wc_get_orders($args);
        $total_orders = wc_get_orders(array_merge($args, array('limit' => -1, 'offset' => 0, 'return' => 'ids')));
        
        $formatted_orders = array();
        foreach ($orders as $order) {
            $formatted_orders[] = woodash_format_order_data($order);
        }
        
        wp_send_json_success(array(
            'orders' => $formatted_orders,
            'total' => count($total_orders),
            'page' => $page,
            'per_page' => $per_page,
            'total_pages' => ceil(count($total_orders) / $per_page)
        ));
        
    } catch (Exception $e) {
        wp_send_json_error('Error fetching orders: ' . $e->getMessage());
    }
}

/**
 * Create new order
 */
function woodash_create_order() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $customer_type = isset($_POST['customer_type']) ? sanitize_text_field($_POST['customer_type']) : 'existing';
        $customer_id = isset($_POST['customer_id']) ? intval($_POST['customer_id']) : 0;
        $billing_data = isset($_POST['billing']) ? $_POST['billing'] : array();
        $items = isset($_POST['items']) ? $_POST['items'] : array();
        $order_status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'pending';
        $payment_method = isset($_POST['payment_method']) ? sanitize_text_field($_POST['payment_method']) : '';
        $payment_status = isset($_POST['payment_status']) ? sanitize_text_field($_POST['payment_status']) : 'pending';
        $order_notes = isset($_POST['notes']) ? sanitize_textarea_field($_POST['notes']) : '';
        $tax_rate = isset($_POST['tax_rate']) ? floatval($_POST['tax_rate']) : 0;
        $shipping_cost = isset($_POST['shipping_cost']) ? floatval($_POST['shipping_cost']) : 0;
        
        // Create new customer if needed
        if ($customer_type === 'new') {
            $first_name = sanitize_text_field($_POST['first_name']);
            $last_name = sanitize_text_field($_POST['last_name']);
            $email = sanitize_email($_POST['customer_email']);
            $phone = sanitize_text_field($_POST['customer_phone']);
            
            if (!$email) {
                wp_send_json_error('Customer email is required');
            }
            
            // Check if customer already exists
            $existing_customer = get_user_by('email', $email);
            if ($existing_customer) {
                $customer_id = $existing_customer->ID;
            } else {
                // Create new customer
                $customer_id = wc_create_new_customer($email, '', '', array(
                    'first_name' => $first_name,
                    'last_name' => $last_name,
                ));
                
                if (is_wp_error($customer_id)) {
                    wp_send_json_error('Error creating customer: ' . $customer_id->get_error_message());
                }
                
                // Add phone number
                if ($phone) {
                    update_user_meta($customer_id, 'billing_phone', $phone);
                }
            }
        }
        
        // Create new order
        $order = wc_create_order();
        
        // Set customer
        if ($customer_id > 0) {
            $order->set_customer_id($customer_id);
        }
        
        // Set billing address
        if (!empty($billing_data)) {
            $billing_address = array(
                'first_name' => sanitize_text_field($billing_data['first_name']),
                'last_name' => sanitize_text_field($billing_data['last_name']),
                'address_1' => sanitize_text_field($billing_data['address_1']),
                'address_2' => sanitize_text_field($billing_data['address_2']),
                'city' => sanitize_text_field($billing_data['city']),
                'state' => sanitize_text_field($billing_data['state']),
                'postcode' => sanitize_text_field($billing_data['postcode']),
                'country' => sanitize_text_field($billing_data['country']),
                'email' => sanitize_email($billing_data['email']),
                'phone' => sanitize_text_field($billing_data['phone']),
            );
            $order->set_address($billing_address, 'billing');
        }
        
        // Add products
        foreach ($items as $item) {
            $product_id = intval($item['product_id']);
            $quantity = intval($item['quantity']);
            $custom_price = isset($item['price']) ? floatval($item['price']) : null;
            
            $product = wc_get_product($product_id);
            
            if ($product) {
                $item_id = $order->add_product($product, $quantity);
                
                // Set custom price if provided
                if ($custom_price && $item_id) {
                    $order_item = $order->get_item($item_id);
                    $order_item->set_subtotal($custom_price * $quantity);
                    $order_item->set_total($custom_price * $quantity);
                    $order_item->save();
                }
            }
        }
        
        // Add shipping
        if ($shipping_cost > 0) {
            $shipping_item = new WC_Order_Item_Shipping();
            $shipping_item->set_method_title('Custom Shipping');
            $shipping_item->set_method_id('custom_shipping');
            $shipping_item->set_total($shipping_cost);
            $order->add_item($shipping_item);
        }
        
        // Set order status
        $order->set_status($order_status);
        
        // Set payment method
        if ($payment_method) {
            $order->set_payment_method($payment_method);
            $order->set_payment_method_title(ucfirst(str_replace('-', ' ', $payment_method)));
        }
        
        // Add order notes
        if ($order_notes) {
            $order->add_order_note($order_notes);
        }
        
        // Calculate totals
        $order->calculate_totals();
        
        // Handle payment status
        if ($payment_status === 'paid') {
            $order->payment_complete();
        }
        
        // Save order
        $order->save();
        
        wp_send_json_success(array(
            'message' => 'Order created successfully',
            'order_id' => $order->get_id(),
            'order' => woodash_format_order_data($order)
        ));
        
    } catch (Exception $e) {
        wp_send_json_error('Error creating order: ' . $e->getMessage());
    }
}

/**
 * Update existing order
 */
function woodash_update_order() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
        $order = wc_get_order($order_id);
        
        if (!$order) {
            wp_send_json_error('Order not found');
        }
        
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
        $payment_status = isset($_POST['payment_status']) ? sanitize_text_field($_POST['payment_status']) : '';
        $notes = isset($_POST['notes']) ? sanitize_textarea_field($_POST['notes']) : '';
        
        if ($status) {
            $order->set_status($status);
        }
        
        if ($payment_status === 'paid') {
            $order->payment_complete();
        }
        
        if ($notes) {
            $order->add_order_note($notes);
        }
        
        $order->save();
        
        wp_send_json_success(array(
            'message' => 'Order updated successfully',
            'order' => woodash_format_order_data($order)
        ));
        
    } catch (Exception $e) {
        wp_send_json_error('Error updating order: ' . $e->getMessage());
    }
}

/**
 * Get order details
 */
function woodash_get_order_details() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
        $order = wc_get_order($order_id);
        
        if (!$order) {
            wp_send_json_error('Order not found');
        }
        
        $order_data = woodash_format_order_data($order, true);
        
        wp_send_json_success($order_data);
        
    } catch (Exception $e) {
        wp_send_json_error('Error fetching order details: ' . $e->getMessage());
    }
}

/**
 * Get customers for dropdown
 */
function woodash_get_customers() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        
        $args = array(
            'role' => 'customer',
            'number' => 100,
            'orderby' => 'display_name',
            'order' => 'ASC'
        );
        
        if ($search) {
            $args['search'] = '*' . $search . '*';
            $args['search_columns'] = array('user_login', 'user_email', 'display_name');
        }
        
        $customers = get_users($args);
        
        $formatted_customers = array();
        foreach ($customers as $customer) {
            $first_name = get_user_meta($customer->ID, 'first_name', true);
            $last_name = get_user_meta($customer->ID, 'last_name', true);
            
            $formatted_customers[] = array(
                'id' => $customer->ID,
                'name' => trim($first_name . ' ' . $last_name) ?: $customer->display_name,
                'email' => $customer->user_email,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'phone' => get_user_meta($customer->ID, 'billing_phone', true),
            );
        }
        
        wp_send_json_success($formatted_customers);
        
    } catch (Exception $e) {
        wp_send_json_error('Error fetching customers: ' . $e->getMessage());
    }
}

/**
 * Get products for order creation
 */
function woodash_get_products() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        
        $args = array(
            'type' => array('simple', 'variable'),
            'status' => 'publish',
            'limit' => 50,
            'orderby' => 'title',
            'order' => 'ASC',
        );
        
        if ($search) {
            $args['s'] = $search;
        }
        
        $products = wc_get_products($args);
        
        $formatted_products = array();
        foreach ($products as $product) {
            $formatted_products[] = array(
                'id' => $product->get_id(),
                'name' => $product->get_name(),
                'price' => $product->get_price(),
                'formatted_price' => wc_price($product->get_price()),
                'stock_status' => $product->get_stock_status(),
                'stock_quantity' => $product->get_stock_quantity(),
                'image' => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail'),
            );
        }
        
        wp_send_json_success($formatted_products);
        
    } catch (Exception $e) {
        wp_send_json_error('Error fetching products: ' . $e->getMessage());
    }
}

/**
 * Get dashboard statistics
 */
function woodash_get_dashboard_stats() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $stats = array(
            'total_orders' => woodash_get_orders_count(),
            'pending_orders' => woodash_get_orders_count('pending'),
            'processing_orders' => woodash_get_orders_count('processing'),
            'completed_orders' => woodash_get_orders_count('completed'),
            'cancelled_orders' => woodash_get_orders_count('cancelled'),
            'total_revenue' => woodash_get_total_revenue(),
            'monthly_revenue' => woodash_get_monthly_revenue(),
            'weekly_revenue' => woodash_get_weekly_revenue(),
            'daily_revenue' => woodash_get_daily_revenue(),
            'recent_orders' => woodash_get_recent_orders(10),
            'top_products' => woodash_get_top_products(5),
            'sales_chart_data' => woodash_get_sales_chart_data(),
        );
        
        wp_send_json_success($stats);
        
    } catch (Exception $e) {
        wp_send_json_error('Error fetching dashboard stats: ' . $e->getMessage());
    }
}

/**
 * Helper Functions
 */

/**
 * Format order data for API response
 */
function woodash_format_order_data($order, $detailed = false) {
    $data = array(
        'id' => '#' . $order->get_order_number(),
        'order_id' => $order->get_id(),
        'status' => $order->get_status(),
        'date' => $order->get_date_created()->format('Y-m-d'),
        'date_created' => $order->get_date_created()->format('Y-m-d H:i:s'),
        'customer' => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
        'email' => $order->get_billing_email(),
        'total' => $order->get_total(),
        'formatted_total' => wc_price($order->get_total()),
        'currency' => $order->get_currency(),
        'payment' => $order->is_paid() ? 'Paid' : 'Pending',
        'payment_method' => $order->get_payment_method_title(),
    );
    
    if ($detailed) {
        $data['billing_address'] = $order->get_address('billing');
        $data['shipping_address'] = $order->get_address('shipping');
        $data['items'] = array();
        
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $data['items'][] = array(
                'id' => $item->get_id(),
                'product_id' => $item->get_product_id(),
                'name' => $item->get_name(),
                'quantity' => $item->get_quantity(),
                'price' => wc_price($item->get_subtotal() / $item->get_quantity()),
                'qty' => $item->get_quantity(),
                'total' => wc_price($item->get_total()),
                'image' => $product ? wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') : '',
            );
        }
        
        $data['order_notes'] = array();
        $notes = $order->get_customer_order_notes();
        foreach ($notes as $note) {
            $data['order_notes'][] = array(
                'date' => $note->comment_date,
                'note' => $note->comment_content,
            );
        }
        
        $data['subtotal'] = wc_price($order->get_subtotal());
        $data['tax'] = wc_price($order->get_total_tax());
        $data['shipping'] = wc_price($order->get_shipping_total());
    }
    
    return $data;
}

/**
 * Get orders count by status
 */
function woodash_get_orders_count($status = '') {
    $args = array('return' => 'ids');
    if ($status) {
        $args['status'] = 'wc-' . $status;
    }
    return count(wc_get_orders($args));
}

/**
 * Get total revenue
 */
function woodash_get_total_revenue() {
    global $wpdb;
    
    $result = $wpdb->get_var("
        SELECT SUM(meta_value) 
        FROM {$wpdb->postmeta} pm
        INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
        WHERE pm.meta_key = '_order_total'
        AND p.post_type = 'shop_order'
        AND p.post_status IN ('wc-completed', 'wc-processing')
    ");
    
    return $result ? floatval($result) : 0;
}

/**
 * Get monthly revenue
 */
function woodash_get_monthly_revenue() {
    global $wpdb;
    
    $result = $wpdb->get_var($wpdb->prepare("
        SELECT SUM(meta_value) 
        FROM {$wpdb->postmeta} pm
        INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
        WHERE pm.meta_key = '_order_total'
        AND p.post_type = 'shop_order'
        AND p.post_status IN ('wc-completed', 'wc-processing')
        AND p.post_date >= %s
    ", date('Y-m-01')));
    
    return $result ? floatval($result) : 0;
}

/**
 * Get weekly revenue
 */
function woodash_get_weekly_revenue() {
    global $wpdb;
    
    $result = $wpdb->get_var($wpdb->prepare("
        SELECT SUM(meta_value) 
        FROM {$wpdb->postmeta} pm
        INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
        WHERE pm.meta_key = '_order_total'
        AND p.post_type = 'shop_order'
        AND p.post_status IN ('wc-completed', 'wc-processing')
        AND p.post_date >= %s
    ", date('Y-m-d', strtotime('-7 days'))));
    
    return $result ? floatval($result) : 0;
}

/**
 * Get daily revenue
 */
function woodash_get_daily_revenue() {
    global $wpdb;
    
    $result = $wpdb->get_var($wpdb->prepare("
        SELECT SUM(meta_value) 
        FROM {$wpdb->postmeta} pm
        INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
        WHERE pm.meta_key = '_order_total'
        AND p.post_type = 'shop_order'
        AND p.post_status IN ('wc-completed', 'wc-processing')
        AND DATE(p.post_date) = %s
    ", date('Y-m-d')));
    
    return $result ? floatval($result) : 0;
}

/**
 * Get recent orders
 */
function woodash_get_recent_orders($limit = 5) {
    $orders = wc_get_orders(array(
        'limit' => $limit,
        'orderby' => 'date',
        'order' => 'DESC',
    ));
    
    $recent_orders = array();
    foreach ($orders as $order) {
        $recent_orders[] = woodash_format_order_data($order);
    }
    
    return $recent_orders;
}

/**
 * Get top selling products
 */
function woodash_get_top_products($limit = 5) {
    global $wpdb;
    
    $results = $wpdb->get_results($wpdb->prepare("
        SELECT 
            oim.meta_value as product_id,
            p.post_title as product_name,
            SUM(oim2.meta_value) as total_sales,
            SUM(oim3.meta_value) as total_revenue
        FROM {$wpdb->prefix}woocommerce_order_items oi
        INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim ON oi.order_item_id = oim.order_item_id
        INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim2 ON oi.order_item_id = oim2.order_item_id
        INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim3 ON oi.order_item_id = oim3.order_item_id
        INNER JOIN {$wpdb->posts} p ON oim.meta_value = p.ID
        INNER JOIN {$wpdb->posts} ord ON oi.order_id = ord.ID
        WHERE oim.meta_key = '_product_id'
        AND oim2.meta_key = '_qty'
        AND oim3.meta_key = '_line_total'
        AND ord.post_status IN ('wc-completed', 'wc-processing')
        AND p.post_status = 'publish'
        GROUP BY oim.meta_value
        ORDER BY total_sales DESC
        LIMIT %d
    ", $limit));
    
    $top_products = array();
    foreach ($results as $result) {
        $product = wc_get_product($result->product_id);
        if ($product) {
            $top_products[] = array(
                'id' => $result->product_id,
                'name' => $result->product_name,
                'total_sales' => intval($result->total_sales),
                'total_revenue' => floatval($result->total_revenue),
                'formatted_revenue' => wc_price($result->total_revenue),
                'image' => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail'),
            );
        }
    }
    
    return $top_products;
}

/**
 * Get sales chart data for the last 30 days
 */
function woodash_get_sales_chart_data() {
    global $wpdb;
    
    $data = array();
    
    for ($i = 29; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime('-' . $i . ' days'));
        
        $revenue = $wpdb->get_var($wpdb->prepare("
            SELECT SUM(meta_value) 
            FROM {$wpdb->postmeta} pm
            INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
            WHERE pm.meta_key = '_order_total'
            AND p.post_type = 'shop_order'
            AND p.post_status IN ('wc-completed', 'wc-processing')
            AND DATE(p.post_date) = %s
        ", $date));
        
        $orders_count = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) 
            FROM {$wpdb->posts} p
            WHERE p.post_type = 'shop_order'
            AND p.post_status IN ('wc-completed', 'wc-processing')
            AND DATE(p.post_date) = %s
        ", $date));
        
        $data[] = array(
            'date' => $date,
            'revenue' => floatval($revenue ?: 0),
            'orders' => intval($orders_count ?: 0),
        );
    }
    
    return $data;
}

/**
 * Create new product
 */
function woodash_create_product() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $name = sanitize_text_field($_POST['name']);
        $description = sanitize_textarea_field($_POST['description']);
        $price = floatval($_POST['price']);
        $sale_price = isset($_POST['sale_price']) ? floatval($_POST['sale_price']) : '';
        $stock_quantity = intval($_POST['stock_quantity']);
        $sku = sanitize_text_field($_POST['sku']);
        $category_ids = isset($_POST['category_ids']) ? array_map('intval', $_POST['category_ids']) : array();
        
        // Create product
        $product = new WC_Product_Simple();
        $product->set_name($name);
        $product->set_description($description);
        $product->set_regular_price($price);
        
        if ($sale_price) {
            $product->set_sale_price($sale_price);
        }
        
        $product->set_stock_quantity($stock_quantity);
        $product->set_manage_stock(true);
        $product->set_sku($sku);
        $product->set_category_ids($category_ids);
        $product->set_status('publish');
        
        $product_id = $product->save();
        
        wp_send_json_success(array(
            'message' => 'Product created successfully',
            'product_id' => $product_id,
            'product' => woodash_format_product_data($product)
        ));
        
    } catch (Exception $e) {
        wp_send_json_error('Error creating product: ' . $e->getMessage());
    }
}

/**
 * Update existing product
 */
function woodash_update_product() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $product_id = intval($_POST['product_id']);
        $product = wc_get_product($product_id);
        
        if (!$product) {
            wp_send_json_error('Product not found');
        }
        
        if (isset($_POST['name'])) {
            $product->set_name(sanitize_text_field($_POST['name']));
        }
        
        if (isset($_POST['price'])) {
            $product->set_regular_price(floatval($_POST['price']));
        }
        
        if (isset($_POST['sale_price'])) {
            $sale_price = $_POST['sale_price'];
            $product->set_sale_price($sale_price ? floatval($sale_price) : '');
        }
        
        if (isset($_POST['stock_quantity'])) {
            $product->set_stock_quantity(intval($_POST['stock_quantity']));
        }
        
        if (isset($_POST['status'])) {
            $product->set_status(sanitize_text_field($_POST['status']));
        }
        
        $product->save();
        
        wp_send_json_success(array(
            'message' => 'Product updated successfully',
            'product' => woodash_format_product_data($product)
        ));
        
    } catch (Exception $e) {
        wp_send_json_error('Error updating product: ' . $e->getMessage());
    }
}

/**
 * Delete product
 */
function woodash_delete_product() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $product_id = intval($_POST['product_id']);
        
        $result = wp_delete_post($product_id, true);
        
        if ($result) {
            wp_send_json_success(array(
                'message' => 'Product deleted successfully'
            ));
        } else {
            wp_send_json_error('Failed to delete product');
        }
        
    } catch (Exception $e) {
        wp_send_json_error('Error deleting product: ' . $e->getMessage());
    }
}

/**
 * Get product statistics
 */
function woodash_get_product_stats() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $stats = array(
            'total_products' => wp_count_posts('product')->publish,
            'out_of_stock' => woodash_get_out_of_stock_count(),
            'low_stock' => woodash_get_low_stock_count(),
            'categories' => wp_count_terms('product_cat'),
            'revenue_by_product' => woodash_get_revenue_by_product(10),
            'stock_alerts' => woodash_get_stock_alerts(),
        );
        
        wp_send_json_success($stats);
        
    } catch (Exception $e) {
        wp_send_json_error('Error fetching product stats: ' . $e->getMessage());
    }
}

/**
 * Format product data for API response
 */
function woodash_format_product_data($product) {
    return array(
        'id' => $product->get_id(),
        'name' => $product->get_name(),
        'sku' => $product->get_sku(),
        'status' => $product->get_status(),
        'price' => $product->get_price(),
        'regular_price' => $product->get_regular_price(),
        'sale_price' => $product->get_sale_price(),
        'formatted_price' => wc_price($product->get_price()),
        'stock_status' => $product->get_stock_status(),
        'stock_quantity' => $product->get_stock_quantity(),
        'manage_stock' => $product->get_manage_stock(),
        'image' => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail'),
        'categories' => wp_get_post_terms($product->get_id(), 'product_cat', array('fields' => 'names')),
        'date_created' => $product->get_date_created()->format('Y-m-d H:i:s'),
        'total_sales' => $product->get_total_sales(),
    );
}

/**
 * Get out of stock products count
 */
function woodash_get_out_of_stock_count() {
    $args = array(
        'type' => array('simple', 'variable'),
        'status' => 'publish',
        'stock_status' => 'outofstock',
        'return' => 'ids',
        'limit' => -1,
    );
    
    return count(wc_get_products($args));
}

/**
 * Get low stock products count
 */
function woodash_get_low_stock_count() {
    global $wpdb;
    
    $low_stock_threshold = get_option('woocommerce_notify_low_stock_amount', 2);
    
    $result = $wpdb->get_var($wpdb->prepare("
        SELECT COUNT(DISTINCT p.ID)
        FROM {$wpdb->posts} p
        INNER JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id
        INNER JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id
        WHERE p.post_type = 'product'
        AND p.post_status = 'publish'
        AND pm1.meta_key = '_manage_stock'
        AND pm1.meta_value = 'yes'
        AND pm2.meta_key = '_stock'
        AND CAST(pm2.meta_value AS UNSIGNED) <= %d
        AND CAST(pm2.meta_value AS UNSIGNED) > 0
    ", $low_stock_threshold));
    
    return intval($result);
}

/**
 * Get revenue by product
 */
function woodash_get_revenue_by_product($limit = 10) {
    global $wpdb;
    
    $results = $wpdb->get_results($wpdb->prepare("
        SELECT 
            oim.meta_value as product_id,
            p.post_title as product_name,
            SUM(oim2.meta_value) as total_sales,
            SUM(oim3.meta_value) as total_revenue
        FROM {$wpdb->prefix}woocommerce_order_items oi
        INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim ON oi.order_item_id = oim.order_item_id
        INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim2 ON oi.order_item_id = oim2.order_item_id
        INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim3 ON oi.order_item_id = oim3.order_item_id
        INNER JOIN {$wpdb->posts} p ON oim.meta_value = p.ID
        INNER JOIN {$wpdb->posts} ord ON oi.order_id = ord.ID
        WHERE oim.meta_key = '_product_id'
        AND oim2.meta_key = '_qty'
        AND oim3.meta_key = '_line_total'
        AND ord.post_status IN ('wc-completed', 'wc-processing')
        AND p.post_status = 'publish'
        GROUP BY oim.meta_value
        ORDER BY total_revenue DESC
        LIMIT %d
    ", $limit));
    
    $revenue_data = array();
    foreach ($results as $result) {
        $revenue_data[] = array(
            'product_id' => $result->product_id,
            'product_name' => $result->product_name,
            'total_sales' => intval($result->total_sales),
            'total_revenue' => floatval($result->total_revenue),
            'formatted_revenue' => wc_price($result->total_revenue),
        );
    }
    
    return $revenue_data;
}

/**
 * Get stock alerts (low stock and out of stock products)
 */
function woodash_get_stock_alerts() {
    $low_stock_threshold = get_option('woocommerce_notify_low_stock_amount', 2);
    
    // Get low stock products
    $low_stock_args = array(
        'type' => array('simple', 'variable'),
        'status' => 'publish',
        'manage_stock' => true,
        'stock_quantity' => array(1, $low_stock_threshold),
        'limit' => 10,
    );
    
    // Get out of stock products
    $out_of_stock_args = array(
        'type' => array('simple', 'variable'),
        'status' => 'publish',
        'stock_status' => 'outofstock',
        'limit' => 10,
    );
    
    $low_stock_products = wc_get_products($low_stock_args);
    $out_of_stock_products = wc_get_products($out_of_stock_args);
    
    $alerts = array();
    
    foreach ($low_stock_products as $product) {
        $alerts[] = array(
            'type' => 'low_stock',
            'product_id' => $product->get_id(),
            'product_name' => $product->get_name(),
            'stock_quantity' => $product->get_stock_quantity(),
            'severity' => 'warning',
        );
    }
    
    foreach ($out_of_stock_products as $product) {
        $alerts[] = array(
            'type' => 'out_of_stock',
            'product_id' => $product->get_id(),
            'product_name' => $product->get_name(),
            'stock_quantity' => 0,
            'severity' => 'danger',
        );
    }
    
    return $alerts;
}



// ========================================
// EXTENDED CUSTOMER MANAGEMENT ENDPOINTS
// ========================================

/**
 * Get detailed customer information
 */
function woodash_get_customer_details() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $customer_id = isset($_POST['customer_id']) ? intval($_POST['customer_id']) : 0;
    if (!$customer_id) {
        wp_send_json_error('Customer ID required');
    }

    try {
        $customer = new WC_Customer($customer_id);
        if (!$customer->get_id()) {
            wp_send_json_error('Customer not found');
        }

        $orders = wc_get_orders(['customer_id' => $customer_id, 'limit' => -1]);
        $total_spent = 0;
        foreach ($orders as $order) {
            $total_spent += (float) $order->get_total();
        }

        $data = [
            'id' => $customer->get_id(),
            'first_name' => $customer->get_first_name(),
            'last_name' => $customer->get_last_name(),
            'email' => $customer->get_email(),
            'username' => $customer->get_username(),
            'date_created' => $customer->get_date_created()->date('Y-m-d H:i:s'),
            'total_orders' => count($orders),
            'total_spent' => $total_spent,
            'avatar_url' => get_avatar_url($customer->get_email()),
            'billing' => [
                'first_name' => $customer->get_billing_first_name(),
                'last_name' => $customer->get_billing_last_name(),
                'company' => $customer->get_billing_company(),
                'address_1' => $customer->get_billing_address_1(),
                'address_2' => $customer->get_billing_address_2(),
                'city' => $customer->get_billing_city(),
                'state' => $customer->get_billing_state(),
                'postcode' => $customer->get_billing_postcode(),
                'country' => $customer->get_billing_country(),
                'phone' => $customer->get_billing_phone(),
            ]
        ];

        wp_send_json_success($data);
    } catch (Exception $e) {
        wp_send_json_error('Error fetching customer: ' . $e->getMessage());
    }
}

/**
 * Update customer information
 */
function woodash_update_customer() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $customer_id = isset($_POST['customer_id']) ? intval($_POST['customer_id']) : 0;
    if (!$customer_id) {
        wp_send_json_error('Customer ID required');
    }

    try {
        $customer = new WC_Customer($customer_id);
        if (!$customer->get_id()) {
            wp_send_json_error('Customer not found');
        }

        // Update basic info
        if (isset($_POST['first_name'])) $customer->set_first_name(sanitize_text_field($_POST['first_name']));
        if (isset($_POST['last_name'])) $customer->set_last_name(sanitize_text_field($_POST['last_name']));
        if (isset($_POST['email'])) $customer->set_email(sanitize_email($_POST['email']));

        // Update billing info
        if (isset($_POST['billing_first_name'])) $customer->set_billing_first_name(sanitize_text_field($_POST['billing_first_name']));
        if (isset($_POST['billing_last_name'])) $customer->set_billing_last_name(sanitize_text_field($_POST['billing_last_name']));
        if (isset($_POST['billing_company'])) $customer->set_billing_company(sanitize_text_field($_POST['billing_company']));
        if (isset($_POST['billing_address_1'])) $customer->set_billing_address_1(sanitize_text_field($_POST['billing_address_1']));
        if (isset($_POST['billing_city'])) $customer->set_billing_city(sanitize_text_field($_POST['billing_city']));
        if (isset($_POST['billing_phone'])) $customer->set_billing_phone(sanitize_text_field($_POST['billing_phone']));

        $customer->save();

        wp_send_json_success(['message' => 'Customer updated successfully']);
    } catch (Exception $e) {
        wp_send_json_error('Error updating customer: ' . $e->getMessage());
    }
}

/**
 * Delete customer
 */
function woodash_delete_customer() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $customer_id = isset($_POST['customer_id']) ? intval($_POST['customer_id']) : 0;
    if (!$customer_id) {
        wp_send_json_error('Customer ID required');
    }

    try {
        $result = wp_delete_user($customer_id);
        if ($result) {
            wp_send_json_success(['message' => 'Customer deleted successfully']);
        } else {
            wp_send_json_error('Failed to delete customer');
        }
    } catch (Exception $e) {
        wp_send_json_error('Error deleting customer: ' . $e->getMessage());
    }
}

/**
 * Get customer orders
 */
function woodash_get_customer_orders() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $customer_id = isset($_POST['customer_id']) ? intval($_POST['customer_id']) : 0;
    if (!$customer_id) {
        wp_send_json_error('Customer ID required');
    }

    try {
        $orders = wc_get_orders(['customer_id' => $customer_id, 'limit' => -1]);
        $formatted_orders = [];

        foreach ($orders as $order) {
            $formatted_orders[] = woodash_format_order_data($order, false);
        }

        wp_send_json_success($formatted_orders);
    } catch (Exception $e) {
        wp_send_json_error('Error fetching customer orders: ' . $e->getMessage());
    }
}

/**
 * Get customer statistics
 */
function woodash_get_customer_stats() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $total_customers = count_users()['total_users'];
        $new_customers_30_days = count(get_users([
            'date_query' => [
                'after' => '30 days ago'
            ]
        ]));

        // Get top customers by total spent
        $customer_query = get_users(['number' => 5]);
        $top_customers = [];
        
        foreach ($customer_query as $user) {
            $customer = new WC_Customer($user->ID);
            $orders = wc_get_orders(['customer_id' => $user->ID, 'limit' => -1]);
            $total_spent = 0;
            foreach ($orders as $order) {
                $total_spent += (float) $order->get_total();
            }
            
            if ($total_spent > 0) {
                $top_customers[] = [
                    'id' => $user->ID,
                    'name' => $customer->get_first_name() . ' ' . $customer->get_last_name(),
                    'email' => $customer->get_email(),
                    'total_spent' => $total_spent,
                    'order_count' => count($orders)
                ];
            }
        }

        // Sort by total spent
        usort($top_customers, function($a, $b) {
            return $b['total_spent'] - $a['total_spent'];
        });

        wp_send_json_success([
            'total_customers' => $total_customers,
            'new_customers_30_days' => $new_customers_30_days,
            'top_customers' => array_slice($top_customers, 0, 5)
        ]);
    } catch (Exception $e) {
        wp_send_json_error('Error fetching customer stats: ' . $e->getMessage());
    }
}

// ========================================
// REPORTS & ANALYTICS ENDPOINTS
// ========================================

/**
 * Get sales report data
 */
function woodash_get_sales_report() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $date_from = isset($_POST['date_from']) ? sanitize_text_field($_POST['date_from']) : date('Y-m-01');
    $date_to = isset($_POST['date_to']) ? sanitize_text_field($_POST['date_to']) : date('Y-m-d');

    try {
        $orders = wc_get_orders([
            'limit' => -1,
            'date_created' => $date_from . '...' . $date_to,
            'status' => ['wc-completed', 'wc-processing']
        ]);

        $daily_sales = [];
        $total_revenue = 0;
        $total_orders = count($orders);

        foreach ($orders as $order) {
            $date = $order->get_date_created()->date('Y-m-d');
            $total = (float) $order->get_total();
            
            if (!isset($daily_sales[$date])) {
                $daily_sales[$date] = ['revenue' => 0, 'orders' => 0];
            }
            
            $daily_sales[$date]['revenue'] += $total;
            $daily_sales[$date]['orders']++;
            $total_revenue += $total;
        }

        wp_send_json_success([
            'daily_sales' => $daily_sales,
            'total_revenue' => $total_revenue,
            'total_orders' => $total_orders,
            'average_order_value' => $total_orders > 0 ? round($total_revenue / $total_orders, 2) : 0
        ]);
    } catch (Exception $e) {
        wp_send_json_error('Error generating sales report: ' . $e->getMessage());
    }
}

/**
 * Get product report data
 */
function woodash_get_product_report() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        global $wpdb;
        
        // Get top selling products
        $top_products = $wpdb->get_results("
            SELECT p.ID, p.post_title, 
                   SUM(oim.meta_value) as total_sold,
                   SUM(oim2.meta_value) as total_revenue
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim ON p.ID = oim.meta_value
            INNER JOIN {$wpdb->prefix}woocommerce_order_items oi ON oim.order_item_id = oi.order_item_id
            INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim2 ON oi.order_item_id = oim2.order_item_id
            WHERE oim.meta_key = '_product_id' 
              AND oim2.meta_key = '_line_total'
              AND p.post_type = 'product'
            GROUP BY p.ID
            ORDER BY total_sold DESC
            LIMIT 10
        ");

        $formatted_products = [];
        foreach ($top_products as $product) {
            $formatted_products[] = [
                'id' => $product->ID,
                'name' => $product->post_title,
                'total_sold' => (int) $product->total_sold,
                'total_revenue' => (float) $product->total_revenue
            ];
        }

        wp_send_json_success([
            'top_products' => $formatted_products
        ]);
    } catch (Exception $e) {
        wp_send_json_error('Error generating product report: ' . $e->getMessage());
    }
}

// ========================================
// STOCK MANAGEMENT ENDPOINTS
// ========================================

/**
 * Get stock data
 */
function woodash_get_stock_data() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $products = wc_get_products(['limit' => -1]);
        $stock_data = [];
        $low_stock_count = 0;
        $out_of_stock_count = 0;

        foreach ($products as $product) {
            $stock_quantity = $product->get_stock_quantity();
            $stock_status = $product->get_stock_status();
            
            $item = [
                'id' => $product->get_id(),
                'name' => $product->get_name(),
                'sku' => $product->get_sku(),
                'stock_quantity' => $stock_quantity,
                'stock_status' => $stock_status,
                'manage_stock' => $product->get_manage_stock(),
                'low_stock_amount' => $product->get_low_stock_amount()
            ];

            if ($stock_status === 'outofstock') {
                $out_of_stock_count++;
            } elseif ($stock_quantity && $stock_quantity <= ($product->get_low_stock_amount() ?: 5)) {
                $low_stock_count++;
                $item['is_low_stock'] = true;
            }

            $stock_data[] = $item;
        }

        wp_send_json_success([
            'products' => $stock_data,
            'low_stock_count' => $low_stock_count,
            'out_of_stock_count' => $out_of_stock_count,
            'total_products' => count($products)
        ]);
    } catch (Exception $e) {
        wp_send_json_error('Error fetching stock data: ' . $e->getMessage());
    }
}

/**
 * Update product stock
 */
function woodash_update_stock() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $stock_quantity = isset($_POST['stock_quantity']) ? intval($_POST['stock_quantity']) : 0;

    if (!$product_id) {
        wp_send_json_error('Product ID required');
    }

    try {
        $product = wc_get_product($product_id);
        if (!$product) {
            wp_send_json_error('Product not found');
        }

        $product->set_stock_quantity($stock_quantity);
        $product->save();

        wp_send_json_success(['message' => 'Stock updated successfully']);
    } catch (Exception $e) {
        wp_send_json_error('Error updating stock: ' . $e->getMessage());
    }
}

// ========================================
// REVIEWS MANAGEMENT ENDPOINTS
// ========================================

/**
 * Get product reviews
 */
function woodash_get_reviews() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    try {
        $reviews = get_comments([
            'post_type' => 'product',
            'status' => 'all',
            'number' => 50
        ]);

        $formatted_reviews = [];
        foreach ($reviews as $review) {
            $product = wc_get_product($review->comment_post_ID);
            $rating = get_comment_meta($review->comment_ID, 'rating', true);

            $formatted_reviews[] = [
                'id' => $review->comment_ID,
                'product_id' => $review->comment_post_ID,
                'product_name' => $product ? $product->get_name() : 'Product not found',
                'author' => $review->comment_author,
                'author_email' => $review->comment_author_email,
                'content' => $review->comment_content,
                'rating' => (int) $rating,
                'date' => $review->comment_date,
                'status' => $review->comment_approved
            ];
        }

        wp_send_json_success($formatted_reviews);
    } catch (Exception $e) {
        wp_send_json_error('Error fetching reviews: ' . $e->getMessage());
    }
}

/**
 * Update review status
 */
function woodash_update_review_status() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $review_id = isset($_POST['review_id']) ? intval($_POST['review_id']) : 0;
    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

    if (!$review_id || !$status) {
        wp_send_json_error('Review ID and status required');
    }

    try {
        $result = wp_set_comment_status($review_id, $status);
        if ($result) {
            wp_send_json_success(['message' => 'Review status updated successfully']);
        } else {
            wp_send_json_error('Failed to update review status');
        }
    } catch (Exception $e) {
        wp_send_json_error('Error updating review status: ' . $e->getMessage());
    }
}

// ========================================
// MARKETING ENDPOINTS
// ========================================

/**
 * Get marketing campaigns (using WordPress options for storage)
 */
function woodash_get_campaigns() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $campaigns = get_option('woodash_marketing_campaigns', []);
    wp_send_json_success($campaigns);
}

/**
 * Create marketing campaign
 */
function woodash_create_campaign() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : '';
    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'draft';

    if (!$name || !$type) {
        wp_send_json_error('Campaign name and type required');
    }

    $campaigns = get_option('woodash_marketing_campaigns', []);
    $new_campaign = [
        'id' => uniqid(),
        'name' => $name,
        'type' => $type,
        'status' => $status,
        'created_date' => current_time('mysql'),
        'clicks' => 0,
        'conversions' => 0,
        'revenue' => 0
    ];

    $campaigns[] = $new_campaign;
    update_option('woodash_marketing_campaigns', $campaigns);

    wp_send_json_success(['message' => 'Campaign created successfully', 'campaign' => $new_campaign]);
}

// ========================================
// SETTINGS ENDPOINTS
// ========================================

/**
 * Get plugin settings
 */
function woodash_get_settings() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $settings = get_option('woodash_settings', [
        'currency' => get_woocommerce_currency(),
        'timezone' => get_option('timezone_string'),
        'date_format' => get_option('date_format'),
        'low_stock_threshold' => 5,
        'enable_notifications' => true,
        'dashboard_refresh_interval' => 30
    ]);

    wp_send_json_success($settings);
}

/**
 * Update plugin settings
 */
function woodash_update_settings() {
    check_ajax_referer('woodash_nonce', 'nonce');
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $settings = get_option('woodash_settings', []);
    
    if (isset($_POST['low_stock_threshold'])) {
        $settings['low_stock_threshold'] = intval($_POST['low_stock_threshold']);
    }
    if (isset($_POST['enable_notifications'])) {
        $settings['enable_notifications'] = (bool) $_POST['enable_notifications'];
    }
    if (isset($_POST['dashboard_refresh_interval'])) {
        $settings['dashboard_refresh_interval'] = intval($_POST['dashboard_refresh_interval']);
    }

    update_option('woodash_settings', $settings);
    wp_send_json_success(['message' => 'Settings updated successfully']);
}
