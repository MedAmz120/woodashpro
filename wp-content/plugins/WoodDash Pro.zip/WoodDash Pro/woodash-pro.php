<?php
/*
Plugin Name: WooDash Pro
Plugin URI: https://woodashpro.com
Description: Advanced WooCommerce analytics dashboard with real-time insights, customizable reports, and modern UI.
Version: 2.0.0
Author: WooDash Team
Author URI: https://woodashpro.com
Text Domain: woodash-pro
Domain Path: /languages
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
WC requires at least: 5.0
WC tested up to: 8.5
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Network: false
*/

// Add this to your main plugin file (not in the template)

// Prevent direct access
if (!defined('ABSPATH')) {
    exit('Direct access forbidden.');
}

// Define plugin constants
define('WOODASH_PRO_VERSION', '2.0.0');
define('WOODASH_PRO_PLUGIN_FILE', __FILE__);
define('WOODASH_PRO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WOODASH_PRO_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WOODASH_PRO_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Initialize the plugin
class WoodashPro {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('plugins_loaded', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        register_uninstall_hook(__FILE__, array('WoodashPro', 'uninstall'));
    }
    
    public function init() {
        // Load textdomain
        load_plugin_textdomain('woodash-pro', false, dirname(WOODASH_PRO_PLUGIN_BASENAME) . '/languages');
        
        // Check dependencies
        if (!$this->check_dependencies()) {
            return;
        }
        
        // Load plugin files
        $this->load_files();
        
        // Initialize hooks
        $this->init_hooks();
    }
    
    private function check_dependencies() {
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            return false;
        }
        
        // Check PHP version
        if (version_compare(PHP_VERSION, '7.4', '<')) {
            add_action('admin_notices', array($this, 'php_version_notice'));
            return false;
        }
        
        return true;
    }
    
    public function woocommerce_missing_notice() {
        $class = 'notice notice-error';
        $message = sprintf(
            '<strong>%s</strong> requires WooCommerce to be installed and activated. <a href="%s">Install WooCommerce</a>',
            esc_html__('WooDash Pro', 'woodash-pro'),
            admin_url('plugin-install.php?s=woocommerce&tab=search&type=term')
        );
        printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), $message);
    }
    
    public function php_version_notice() {
        $class = 'notice notice-error';
        $message = sprintf(
            '<strong>%s</strong> requires PHP 7.4 or higher. Your current version is %s.',
            esc_html__('WooDash Pro', 'woodash-pro'),
            PHP_VERSION
        );
        printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), esc_html($message));
    }
    
    private function load_files() {
        // Load helper functions first
        $functions_file = WOODASH_PRO_PLUGIN_DIR . 'includes/functions.php';
        if (file_exists($functions_file)) {
            require_once $functions_file;
        }
        
        // Load data endpoints
        $endpoints_file = WOODASH_PRO_PLUGIN_DIR . 'includes/data-endpoints.php';
        if (file_exists($endpoints_file)) {
            require_once $endpoints_file;
        }
        
        // Load core classes (only if files exist)
        $core_files = array(
            'includes/class-woodash-logger.php',
            'includes/class-woodash-cache.php',
            'includes/class-woodash-settings.php',
            'includes/class-woodash-dashboard.php',
            'includes/class-woodash-api.php',
            'includes/class-woodash-analytics.php',
        );
        
        foreach ($core_files as $file) {
            $file_path = WOODASH_PRO_PLUGIN_DIR . $file;
            if (file_exists($file_path)) {
                require_once $file_path;
            }
        }
    }
    
    private function init_hooks() {
        // Admin menu
        add_action('admin_menu', array($this, 'admin_menu'));
        
        // Scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // FORCE HIDE WordPress sidebar on ALL admin pages
        add_action('admin_head', array($this, 'force_hide_wordpress_sidebar'), 1);
        add_action('admin_footer', array($this, 'force_hide_wordpress_sidebar_footer'), 999);
        add_action('admin_print_styles', array($this, 'force_hide_sidebar_styles'), 1);
        
        // Hide WordPress admin bar completely
        add_action('after_setup_theme', array($this, 'hide_wordpress_admin_bar'));
        add_action('init', array($this, 'disable_admin_bar'));
        add_action('wp_head', array($this, 'hide_admin_bar_css'));
        add_action('admin_head', array($this, 'hide_admin_bar_css'));
        
        // AJAX handlers
        add_action('wp_ajax_woodash_get_data', array($this, 'ajax_get_data'));
        add_action('wp_ajax_woodash_get_dashboard_stats', array($this, 'ajax_get_dashboard_stats'));
        add_action('wp_ajax_woodash_toggle_dashboard', array($this, 'ajax_toggle_dashboard'));
        add_action('wp_ajax_woodash_logout', array($this, 'ajax_logout'));
        
        // Quick Add AJAX handlers
        add_action('wp_ajax_woodash_add_product', array($this, 'ajax_add_product'));
        add_action('wp_ajax_woodash_add_customer', array($this, 'ajax_add_customer'));
        add_action('wp_ajax_woodash_add_order', array($this, 'ajax_add_order'));
        add_action('wp_ajax_woodash_add_coupon', array($this, 'ajax_add_coupon'));
        
        // Marketing AJAX handlers
        add_action('wp_ajax_woodash_get_marketing_stats', array($this, 'ajax_get_marketing_stats'));
        add_action('wp_ajax_woodash_get_campaigns', array($this, 'ajax_get_campaigns'));
        add_action('wp_ajax_woodash_create_campaign', array($this, 'ajax_create_campaign'));
        add_action('wp_ajax_woodash_delete_campaign', array($this, 'ajax_delete_campaign'));
        add_action('wp_ajax_woodash_update_campaign', array($this, 'ajax_update_campaign'));
        
        // Notification AJAX handlers
        add_action('wp_ajax_woodash_get_notifications', array($this, 'ajax_get_notifications'));
        add_action('wp_ajax_woodash_mark_notification_read', array($this, 'ajax_mark_notification_read'));
        add_action('wp_ajax_woodash_mark_all_notifications_read', array($this, 'ajax_mark_all_notifications_read'));
        add_action('wp_ajax_woodash_delete_notification', array($this, 'ajax_delete_notification'));
        add_action('wp_ajax_woodash_clear_all_notifications', array($this, 'ajax_clear_all_notifications'));
        add_action('wp_ajax_woodash_save_notification_settings', array($this, 'ajax_save_notification_settings'));
        add_action('wp_ajax_woodash_get_notification_settings', array($this, 'ajax_get_notification_settings'));
        
        // WooCommerce hooks for real-time notifications
        add_action('woocommerce_new_order', array($this, 'handle_new_order_notification'));
        add_action('woocommerce_order_status_changed', array($this, 'handle_order_status_notification'), 10, 4);
        add_action('woocommerce_low_stock', array($this, 'handle_low_stock_notification'));
        add_action('woocommerce_no_stock', array($this, 'handle_no_stock_notification'));
        add_action('comment_post', array($this, 'handle_new_review_notification'), 10, 3);
        add_action('wp_login', array($this, 'handle_login_notification'), 10, 2);
        add_action('wp_login_failed', array($this, 'handle_failed_login_notification'));
        
        // Add test notification generator (for development)
        add_action('wp_ajax_woodash_create_test_notification', array($this, 'ajax_create_test_notification'));
        
        // Hide WordPress menus if needed
        add_action('admin_menu', array($this, 'maybe_hide_wp_menus'), 999);
        
        // REST API
        add_action('rest_api_init', array($this, 'register_rest_routes'));
    }
    
    public function admin_menu() {
        $is_connected = get_option('woodash_connected', false);
        $hide_dashboard = get_option('woodash_hide_dashboard', false);
        
        if ($is_connected && !$hide_dashboard) {
            // Main dashboard page
            add_menu_page(
                __('WooDash Pro', 'woodash-pro'),
                __('WooDash Pro', 'woodash-pro'),
                'manage_options',
                'woodash-pro',
                array($this, 'dashboard_page'),
                'dashicons-chart-area',
                56
            );
            
            // Add submenu pages
            add_submenu_page('woodash-pro', __('Orders', 'woodash-pro'), __('Orders', 'woodash-pro'), 'manage_woocommerce', 'woodash-pro-orders', array($this, 'orders_page'));
            add_submenu_page('woodash-pro', __('Products', 'woodash-pro'), __('Products', 'woodash-pro'), 'manage_woocommerce', 'woodash-pro-products', array($this, 'products_page'));
            add_submenu_page('woodash-pro', __('Customers', 'woodash-pro'), __('Customers', 'woodash-pro'), 'manage_woocommerce', 'woodash-pro-customers', array($this, 'customers_page'));
            add_submenu_page('woodash-pro', __('Stock', 'woodash-pro'), __('Stock', 'woodash-pro'), 'manage_woocommerce', 'woodash-pro-stock', array($this, 'stock_page'));
            add_submenu_page('woodash-pro', __('Reviews', 'woodash-pro'), __('Reviews', 'woodash-pro'), 'manage_woocommerce', 'woodash-pro-reviews', array($this, 'reviews_page'));
            add_submenu_page('woodash-pro', __('Marketing', 'woodash-pro'), __('Marketing', 'woodash-pro'), 'manage_woocommerce', 'woodash-pro-marketing', array($this, 'marketing_page'));
            add_submenu_page('woodash-pro', __('Reports', 'woodash-pro'), __('Reports', 'woodash-pro'), 'manage_woocommerce', 'woodash-pro-reports', array($this, 'reports_page'));
            add_submenu_page('woodash-pro', __('Settings', 'woodash-pro'), __('Settings', 'woodash-pro'), 'manage_options', 'woodash-pro-settings', array($this, 'settings_page'));
        } else {
            add_menu_page(
                __('WooDash Pro', 'woodash-pro'),
                __('WooDash Pro', 'woodash-pro'),
                'manage_options',
                'woodash-pro-activate',
                array($this, 'activation_page'),
                'dashicons-chart-area',
                56
            );
        }
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'woodash-pro') === false) {
            return;
        }
        
        // Hide WordPress admin interface for WooDash Pro pages
        add_action('admin_head', array($this, 'hide_wordpress_admin_interface'));
        
        // Enqueue styles
        wp_enqueue_style(
            'woodash-tailwind',
            WOODASH_PRO_PLUGIN_URL . 'assets/css/tailwind.min.css',
            array(),
            WOODASH_PRO_VERSION
        );
        
        // Enqueue scripts
        wp_enqueue_script('jquery');
        wp_enqueue_script(
            'chartjs',
            'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.min.js',
            array(),
            '4.4.0',
            true
        );
        
        // Localize script
        wp_localize_script('jquery', 'woodashData', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('woodash_nonce'),
            'restUrl' => rest_url('woodash/v1/'),
            'restNonce' => wp_create_nonce('wp_rest'),
            'adminUrl' => admin_url(),
            'today' => current_time('Y-m-d'),
        ));
    }
    
    /**
     * Hide WordPress admin interface completely for WooDash Pro pages
     */
    public function hide_wordpress_admin_interface() {
        ?>
        <style type="text/css">
            /* FORCE HIDE WordPress admin sidebar completely - Multiple selectors for maximum coverage */
            #adminmenumain,
            #adminmenuback,
            #adminmenuwrap,
            .wp-admin #adminmenumain,
            .wp-admin #adminmenuback,
            .wp-admin #adminmenuwrap,
            body.wp-admin #adminmenumain,
            body.wp-admin #adminmenuback,
            body.wp-admin #adminmenuwrap {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
                width: 0 !important;
                height: 0 !important;
                overflow: hidden !important;
                position: absolute !important;
                left: -9999px !important;
            }
            
            /* Hide WordPress admin bar */
            #wpadminbar {
                display: none !important;
                visibility: hidden !important;
            }
            
            /* Hide WordPress footer */
            #wpfooter {
                display: none !important;
            }
            
            /* FORCE full width layout - Remove all left margins and padding */
            #wpcontent,
            .wp-admin #wpcontent,
            body.wp-admin #wpcontent {
                margin-left: 0 !important;
                padding-left: 0 !important;
                margin-right: 0 !important;
                padding-right: 0 !important;
            }
            
            /* FORCE wrapper to full width */
            #wpwrap,
            .wp-admin #wpwrap,
            body.wp-admin #wpwrap {
                padding-top: 0 !important;
                padding-left: 0 !important;
                margin-left: 0 !important;
            }
            
            /* FORCE body to full width */
            #wpbody,
            .wp-admin #wpbody,
            body.wp-admin #wpbody {
                margin-left: 0 !important;
                padding-left: 0 !important;
            }
            
            /* Hide WordPress notices */
            .notice,
            .error,
            .updated {
                display: none !important;
            }
            
            /* Hide screen options and help tabs */
            #screen-meta-links,
            #screen-meta {
                display: none !important;
            }
            
            /* Hide WordPress branding */
            .wp-toolbar,
            #wp-toolbar {
                display: none !important;
            }
            
            /* Make body full width */
            body {
                margin: 0 !important;
                padding: 0 !important;
                background: #f8fafc !important;
            }
            
            /* Hide WordPress page title area */
            .wrap h1:first-child,
            .wp-heading-inline {
                display: none !important;
            }
            
            /* Ensure WooDash Pro content takes full space */
            .woodash-fullscreen {
                position: fixed !important;
                top: 0 !important;
                left: 0 !important;
                right: 0 !important;
                bottom: 0 !important;
                z-index: 999999 !important;
                background: #f8fafc !important;
            }
            
            /* Hide any remaining WordPress elements */
            #wpbody-content > .wrap {
                padding: 0 !important;
                margin: 0 !important;
            }
            
            /* Override WordPress admin styles */
            html.wp-toolbar {
                padding-top: 0 !important;
            }
            
            /* Hide WordPress update notifications */
            .update-nag,
            .notice-warning,
            .notice-info {
                display: none !important;
            }
            
            /* SPECIFIC TARGETING for WooDash Pro Orders page */
            body.toplevel_page_woodash-pro-orders #adminmenumain,
            body.woodash-pro_page_woodash-pro-orders #adminmenumain,
            body[class*="woodash-pro-orders"] #adminmenumain {
                display: none !important;
                visibility: hidden !important;
                width: 0 !important;
                height: 0 !important;
            }
            
            /* Ensure content area is full width on orders page */
            body.toplevel_page_woodash-pro-orders #wpcontent,
            body.woodash-pro_page_woodash-pro-orders #wpcontent,
            body[class*="woodash-pro-orders"] #wpcontent {
                margin-left: 0 !important;
                padding-left: 0 !important;
            }
        </style>
        
        <script type="text/javascript">
            // Enhanced JavaScript to ensure complete sidebar hiding
            document.addEventListener('DOMContentLoaded', function() {
                console.log('WooDash Pro: Hiding WordPress admin interface');
                
                // Function to completely remove sidebar elements
                function removeSidebarElements() {
                    // Remove WordPress admin bar from DOM
                    var adminBar = document.getElementById('wpadminbar');
                    if (adminBar) {
                        adminBar.remove();
                        console.log('WooDash Pro: Admin bar removed');
                    }
                    
                    // Remove admin menu from DOM - Multiple attempts
                    var adminMenuSelectors = [
                        '#adminmenumain',
                        '#adminmenuback', 
                        '#adminmenuwrap',
                        '.wp-menu-separator',
                        '#collapse-menu'
                    ];
                    
                    adminMenuSelectors.forEach(function(selector) {
                        var elements = document.querySelectorAll(selector);
                        elements.forEach(function(element) {
                            if (element) {
                                element.remove();
                                console.log('WooDash Pro: Removed element:', selector);
                            }
                        });
                    });
                    
                    // Remove any WordPress notices
                    var notices = document.querySelectorAll('.notice, .error, .updated');
                    notices.forEach(function(notice) {
                        notice.remove();
                    });
                    
                    // Force content area to full width
                    var contentArea = document.getElementById('wpcontent');
                    if (contentArea) {
                        contentArea.style.marginLeft = '0';
                        contentArea.style.paddingLeft = '0';
                        console.log('WooDash Pro: Content area set to full width');
                    }
                    
                    var wpBody = document.getElementById('wpbody');
                    if (wpBody) {
                        wpBody.style.marginLeft = '0';
                        wpBody.style.paddingLeft = '0';
                    }
                    
                    // Ensure body has no WordPress classes
                    document.body.className = document.body.className.replace(/wp-admin|admin-bar|no-js/g, '');
                    
                    // Add WooDash Pro class
                    document.body.classList.add('woodash-pro-fullscreen');
                    
                    console.log('WooDash Pro: Interface hiding complete');
                }
                
                // Run immediately
                removeSidebarElements();
                
                // Run again after a short delay to catch any dynamically loaded elements
                setTimeout(removeSidebarElements, 100);
                setTimeout(removeSidebarElements, 500);
                
                // Monitor for any attempts to show the sidebar and hide it again
                var observer = new MutationObserver(function(mutations) {
                    mutations.forEach(function(mutation) {
                        if (mutation.type === 'childList') {
                            var adminMenu = document.getElementById('adminmenumain');
                            if (adminMenu && adminMenu.style.display !== 'none') {
                                adminMenu.style.display = 'none';
                                adminMenu.style.visibility = 'hidden';
                                console.log('WooDash Pro: Re-hidden admin menu');
                            }
                        }
                    });
                });
                
                observer.observe(document.body, {
                    childList: true,
                    subtree: true
                });
            });
        </script>
        <?php
    }
    
    public function admin_bar_menu($wp_admin_bar) {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $is_connected = get_option('woodash_connected', false);
        if (!$is_connected) {
            return;
        }
        
        $hide_dashboard = get_option('woodash_hide_dashboard', false);
        $icon = $hide_dashboard ? 'visibility' : 'hidden';
        $title = $hide_dashboard ? __('Show WooDash Pro', 'woodash-pro') : __('Hide WooDash Pro', 'woodash-pro');
        
        $wp_admin_bar->add_node(array(
            'id' => 'woodash-toggle-dashboard',
            'title' => '<span class="ab-icon dashicons dashicons-' . $icon . '"></span><span class="ab-label">' . $title . '</span>',
            'href' => '#',
            'meta' => array('class' => 'woodash-toggle-btn')
        ));
    }
    
    public function maybe_hide_wp_menus() {
        // Always hide WordPress dashboard menus when WooDash Pro is connected
        $is_connected = get_option('woodash_connected', false);
        $hide_wp_dashboard = get_option('woodash_hide_wp_dashboard', true); // Default to true
        
        if ($is_connected && $hide_wp_dashboard) {
            // Hide WordPress core menus
            remove_menu_page('index.php');                    // Dashboard
            remove_menu_page('edit.php');                     // Posts
            remove_menu_page('upload.php');                   // Media
            remove_menu_page('edit.php?post_type=page');      // Pages
            remove_menu_page('edit-comments.php');            // Comments
            remove_menu_page('themes.php');                   // Appearance
            remove_menu_page('plugins.php');                  // Plugins
            remove_menu_page('users.php');                    // Users
            remove_menu_page('tools.php');                    // Tools
            remove_menu_page('options-general.php');          // Settings
            
            // Hide WooCommerce menus (they'll be accessible through WooDash Pro)
            remove_menu_page('woocommerce');                  // WooCommerce
            remove_menu_page('edit.php?post_type=product');   // Products
            remove_menu_page('edit.php?post_type=shop_order'); // Orders
            remove_menu_page('edit.php?post_type=shop_coupon'); // Coupons
            
            // Hide other common plugin menus
            remove_menu_page('edit.php?post_type=elementor_library'); // Elementor
            remove_menu_page('edit.php?post_type=acf-field-group');   // ACF
            remove_menu_page('admin.php?page=wc-admin');              // WooCommerce Admin
            
            // Also hide from admin bar
            add_action('wp_before_admin_bar_render', array($this, 'hide_admin_bar_items'));
        }
    }
    
    /**
     * Hide WordPress items from admin bar
     */
    public function hide_admin_bar_items() {
        global $wp_admin_bar;
        
        // Remove WordPress logo and menu
        $wp_admin_bar->remove_menu('wp-logo');
        
        // Remove "New" menu items
        $wp_admin_bar->remove_menu('new-content');
        
        // Remove comments
        $wp_admin_bar->remove_menu('comments');
        
        // Remove updates
        $wp_admin_bar->remove_menu('updates');
        
        // Keep only essential items like user menu and WooDash Pro items
    }
    
    /**
     * Hide WordPress admin bar completely
     */
    public function hide_wordpress_admin_bar() {
        $is_connected = get_option('woodash_connected', false);
        if ($is_connected) {
            show_admin_bar(false);
        }
    }
    
    /**
     * Disable admin bar for all users when WooDash Pro is connected
     */
    public function disable_admin_bar() {
        $is_connected = get_option('woodash_connected', false);
        if ($is_connected) {
            add_filter('show_admin_bar', '__return_false');
        }
    }
    
    /**
     * Hide admin bar with CSS
     */
    public function hide_admin_bar_css() {
        $is_connected = get_option('woodash_connected', false);
        if ($is_connected) {
            ?>
            <style type="text/css">
                /* Hide WordPress admin bar completely */
                #wpadminbar {
                    display: none !important;
                }
                
                /* Remove admin bar space from top */
                html.wp-toolbar {
                    padding-top: 0 !important;
                }
                
                body.admin-bar {
                    margin-top: 0 !important;
                }
                
                /* Hide admin bar on frontend */
                body {
                    margin-top: 0 !important;
                }
                
                /* Ensure no admin bar spacing */
                .admin-bar #wphead {
                    padding-top: 0 !important;
                }
                
                /* Remove any admin bar related margins */
                .admin-bar #wpcontent,
                .admin-bar #wpbody {
                    padding-top: 0 !important;
                }
            </style>
            <?php
        }
    }
    
    // AJAX handlers
    public function ajax_get_data() {
        check_ajax_referer('woodash_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(__('Unauthorized', 'woodash-pro'), 403);
        }
        
        // Get basic analytics data
        $args = array(
            'status' => array('wc-completed'),
            'limit' => -1,
            'return' => 'ids'
        );
        
        $order_ids = wc_get_orders($args);
        $total_sales = 0;
        $orders = array();
        
        foreach ($order_ids as $order_id) {
            $order = wc_get_order($order_id);
            if ($order) {
                $total_sales += (float) $order->get_total();
                $orders[] = $order;
            }
        }
        
        $total_orders = count($orders);
        $aov = $total_orders > 0 ? round($total_sales / $total_orders, 2) : 0;
        
        wp_send_json(array(
            'total_sales' => wc_format_decimal($total_sales, 2),
            'total_orders' => $total_orders,
            'aov' => $aov,
            'top_products' => array(),
            'top_customers' => array(),
            'sales_overview' => array('labels' => array(), 'data' => array())
        ));
    }
    
    public function ajax_get_dashboard_stats() {
        check_ajax_referer('woodash_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(__('Unauthorized', 'woodash-pro'), 403);
        }
        
        // Get enhanced dashboard statistics
        $today = current_time('Y-m-d');
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $last_30_days = date('Y-m-d', strtotime('-30 days'));
        
        // Get orders data
        $today_orders = wc_get_orders(array(
            'status' => array('wc-completed', 'wc-processing'),
            'date_created' => $today,
            'limit' => -1
        ));
        
        $month_orders = wc_get_orders(array(
            'status' => array('wc-completed', 'wc-processing'),
            'date_created' => '>=' . $last_30_days,
            'limit' => -1
        ));
        
        // Calculate metrics
        $today_sales = 0;
        $month_sales = 0;
        $total_customers = 0;
        
        foreach ($today_orders as $order) {
            $today_sales += $order->get_total();
        }
        
        foreach ($month_orders as $order) {
            $month_sales += $order->get_total();
        }
        
        // Get unique customers count
        $customer_query = new WP_User_Query(array(
            'role' => 'customer',
            'count_total' => true
        ));
        $total_customers = $customer_query->get_total();
        
        // Get pending orders
        $pending_orders = wc_get_orders(array(
            'status' => array('wc-pending', 'wc-on-hold'),
            'limit' => -1
        ));
        
        // Get low stock products
        $low_stock_products = array();
        $products = wc_get_products(array(
            'status' => 'publish',
            'stock_status' => 'instock',
            'limit' => -1
        ));
        
        foreach ($products as $product) {
            if ($product->managing_stock() && $product->get_stock_quantity() <= get_option('woocommerce_notify_low_stock_amount', 2)) {
                $low_stock_products[] = $product;
            }
        }
        
        // Prepare response data
        $response = array(
            'metrics' => array(
                'today_sales' => array(
                    'value' => wc_price($today_sales),
                    'raw' => $today_sales,
                    'count' => count($today_orders)
                ),
                'month_sales' => array(
                    'value' => wc_price($month_sales),
                    'raw' => $month_sales,
                    'count' => count($month_orders)
                ),
                'total_customers' => $total_customers,
                'pending_orders' => count($pending_orders),
                'low_stock_items' => count($low_stock_products)
            ),
            'recent_orders' => array(),
            'top_products' => array(),
            'notifications_count' => $this->get_unread_notifications_count()
        );
        
        // Get recent orders
        $recent_orders = wc_get_orders(array(
            'limit' => 5,
            'orderby' => 'date',
            'order' => 'DESC'
        ));
        
        foreach ($recent_orders as $order) {
            $response['recent_orders'][] = array(
                'id' => '#' . $order->get_order_number(),
                'customer' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                'total' => $order->get_formatted_order_total(),
                'status' => $order->get_status(),
                'date' => $order->get_date_created()->format('M j, Y')
            );
        }
        
        // Get top products
        $top_products_query = new WP_Query(array(
            'post_type' => 'product',
            'posts_per_page' => 5,
            'meta_key' => 'total_sales',
            'orderby' => 'meta_value_num',
            'order' => 'DESC'
        ));
        
        if ($top_products_query->have_posts()) {
            while ($top_products_query->have_posts()) {
                $top_products_query->the_post();
                $product = wc_get_product(get_the_ID());
                if ($product) {
                    $response['top_products'][] = array(
                        'name' => $product->get_name(),
                        'sales' => get_post_meta(get_the_ID(), 'total_sales', true) ?: 0,
                        'price' => $product->get_price_html(),
                        'image' => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail')
                    );
                }
            }
            wp_reset_postdata();
        }
        
        wp_send_json_success($response);
    }
    
    private function get_unread_notifications_count() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'woodash_notifications';
        $user_id = get_current_user_id();
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND is_read = 0",
            $user_id
        ));
        
        return $count ? intval($count) : 0;
    }
    
    public function ajax_toggle_dashboard() {
        check_ajax_referer('woodash_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'woodash-pro'));
        }
        
        $current_state = get_option('woodash_hide_dashboard', false);
        $new_state = !$current_state;
        
        update_option('woodash_hide_dashboard', $new_state);
        
        wp_send_json_success(array(
            'hidden' => $new_state,
            'message' => $new_state 
                ? __('WooDash Pro dashboard hidden', 'woodash-pro') 
                : __('WooDash Pro dashboard shown', 'woodash-pro')
        ));
    }
    
    public function ajax_logout() {
        check_ajax_referer('woodash_nonce', 'nonce');
        
        delete_option('woodash_connected');
        delete_option('woodash_store_id');
        delete_option('woodash_api_key');
        
        wp_send_json_success(array(
            'redirect_url' => admin_url('admin.php?page=woodash-pro-activate')
        ));
    }
    
    public function register_rest_routes() {
        register_rest_route('woodash/v1', '/check-auth', array(
            'methods' => 'GET',
            'callback' => array($this, 'rest_check_auth'),
            'permission_callback' => '__return_true'
        ));
    }
    
    public function rest_check_auth() {
        if (!is_user_logged_in()) {
            return new WP_REST_Response(array(
                'is_logged_in' => false,
                'message' => __('User not logged in', 'woodash-pro')
            ));
        }
        
        $user = wp_get_current_user();
        return new WP_REST_Response(array(
            'is_logged_in' => true,
            'user_id' => $user->ID,
            'user_email' => $user->user_email,
            'display_name' => $user->display_name
        ));
    }
    
    // Page callbacks
    public function dashboard_page() {
        $this->load_template('dashboard');
    }
    
    public function orders_page() {
        $this->load_template('orders');
    }
    
    public function products_page() {
        $this->load_template('products');
    }
    
    public function customers_page() {
        $this->load_template('customers');
    }
    
    public function stock_page() {
        $this->load_template('stock');
    }
    
    public function reviews_page() {
        $this->load_template('reviews');
    }
    
    public function marketing_page() {
        $this->load_template('marketing');
    }
    
    public function reports_page() {
        $this->load_template('reports');
    }
    
    public function settings_page() {
        $this->load_template('settings');
    }
    
    public function activation_page() {
        $this->load_template('activation');
    }
    
    private function load_template($template) {
        $template_file = WOODASH_PRO_PLUGIN_DIR . 'templates/' . $template . '.php';
        if (file_exists($template_file)) {
            include $template_file;
        } else {
            echo '<div class="notice notice-error"><p>' . 
                 sprintf(__('Template file not found: %s', 'woodash-pro'), $template) . 
                 '</p></div>';
        }
    }
    
    public function activate() {
        // Set default options
        update_option('woodash_hide_wp_dashboard', false);
        update_option('woodash_hide_dashboard', false);
        update_option('woodash_version', WOODASH_PRO_VERSION);
        
        // Create notifications table
        $this->create_notifications_table();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    public function deactivate() {
        // Show WordPress dashboard when plugin is deactivated
        update_option('woodash_hide_wp_dashboard', false);
    }
    
    public static function uninstall() {
        // Remove plugin options
        $options_to_delete = array(
            'woodash_hide_wp_dashboard',
            'woodash_hide_dashboard',
            'woodash_connected',
            'woodash_store_id',
            'woodash_api_key',
            'woodash_version',
            'woodash_notifications',
            'woodash_notification_settings'
        );
        
        foreach ($options_to_delete as $option) {
            delete_option($option);
        }
        
        // Remove notification tables
        global $wpdb;
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}woodash_notifications");
    }
    
    // =====================================================
    // NOTIFICATION SYSTEM BACKEND INTEGRATION
    // =====================================================
    
    /**
     * Create notifications table on activation
     */
    public function create_notifications_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'woodash_notifications';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            type varchar(50) NOT NULL,
            priority enum('low', 'medium', 'high') DEFAULT 'medium',
            title varchar(255) NOT NULL,
            message text NOT NULL,
            icon varchar(100) DEFAULT 'fa-bell',
            color varchar(50) DEFAULT '#3B82F6',
            bg_color varchar(50) DEFAULT '#3B82F6',
            actions text DEFAULT NULL,
            metadata text DEFAULT NULL,
            is_read tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            read_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY type (type),
            KEY is_read (is_read),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Create marketing campaigns table
        $campaigns_table = $wpdb->prefix . 'woodash_campaigns';
        $campaigns_sql = "CREATE TABLE $campaigns_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            type varchar(50) NOT NULL DEFAULT 'email',
            status varchar(20) NOT NULL DEFAULT 'draft',
            subject varchar(255),
            content longtext,
            target_audience text,
            settings text,
            clicks int(11) DEFAULT 0,
            opens int(11) DEFAULT 0,
            conversions int(11) DEFAULT 0,
            revenue decimal(10,2) DEFAULT 0.00,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            started_at datetime DEFAULT NULL,
            ended_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY type (type),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        dbDelta($campaigns_sql);
    }
    
    /**
     * Get notifications from database
     */
    public function ajax_get_notifications() {
        check_ajax_referer('woodash_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'woodash-pro'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'woodash_notifications';
        
        $user_id = get_current_user_id();
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 50;
        $offset = isset($_POST['offset']) ? intval($_POST['offset']) : 0;
        $unread_only = isset($_POST['unread_only']) ? boolval($_POST['unread_only']) : false;
        
        $where_clause = "WHERE user_id = %d";
        $params = array($user_id);
        
        if ($unread_only) {
            $where_clause .= " AND is_read = 0";
        }
        
        $sql = "SELECT * FROM $table_name $where_clause ORDER BY created_at DESC LIMIT %d OFFSET %d";
        $params[] = $limit;
        $params[] = $offset;
        
        $notifications = $wpdb->get_results($wpdb->prepare($sql, $params));
        
        // Format notifications for frontend
        $formatted_notifications = array();
        foreach ($notifications as $notification) {
            $formatted_notifications[] = array(
                'id' => intval($notification->id),
                'type' => $notification->type,
                'priority' => $notification->priority,
                'title' => $notification->title,
                'message' => $notification->message,
                'icon' => $notification->icon,
                'color' => $notification->color,
                'bgColor' => $notification->bg_color,
                'actions' => json_decode($notification->actions, true) ?: array(),
                'metadata' => json_decode($notification->metadata, true) ?: array(),
                'unread' => !boolval($notification->is_read),
                'time' => $notification->created_at,
                'sound' => $notification->priority === 'high'
            );
        }
        
        // Get unread count
        $unread_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND is_read = 0",
            $user_id
        ));
        
        wp_send_json_success(array(
            'notifications' => $formatted_notifications,
            'unread_count' => intval($unread_count),
            'total_count' => count($formatted_notifications)
        ));
    }
    
    /**
     * Mark notification as read
     */
    public function ajax_mark_notification_read() {
        check_ajax_referer('woodash_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'woodash-pro'));
        }
        
        $notification_id = isset($_POST['notification_id']) ? intval($_POST['notification_id']) : 0;
        
        if (!$notification_id) {
            wp_send_json_error(__('Invalid notification ID', 'woodash-pro'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'woodash_notifications';
        $user_id = get_current_user_id();
        
        $result = $wpdb->update(
            $table_name,
            array(
                'is_read' => 1,
                'read_at' => current_time('mysql')
            ),
            array(
                'id' => $notification_id,
                'user_id' => $user_id
            ),
            array('%d', '%s'),
            array('%d', '%d')
        );
        
        if ($result !== false) {
            wp_send_json_success(__('Notification marked as read', 'woodash-pro'));
        } else {
            wp_send_json_error(__('Failed to update notification', 'woodash-pro'));
        }
    }
    
    /**
     * Mark all notifications as read
     */
    public function ajax_mark_all_notifications_read() {
        check_ajax_referer('woodash_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'woodash-pro'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'woodash_notifications';
        $user_id = get_current_user_id();
        
        $result = $wpdb->update(
            $table_name,
            array(
                'is_read' => 1,
                'read_at' => current_time('mysql')
            ),
            array(
                'user_id' => $user_id,
                'is_read' => 0
            ),
            array('%d', '%s'),
            array('%d', '%d')
        );
        
        wp_send_json_success(sprintf(__('%d notifications marked as read', 'woodash-pro'), $result));
    }
    
    /**
     * Delete specific notification
     */
    public function ajax_delete_notification() {
        check_ajax_referer('woodash_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'woodash-pro'));
        }
        
        $notification_id = isset($_POST['notification_id']) ? intval($_POST['notification_id']) : 0;
        
        if (!$notification_id) {
            wp_send_json_error(__('Invalid notification ID', 'woodash-pro'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'woodash_notifications';
        $user_id = get_current_user_id();
        
        $result = $wpdb->delete(
            $table_name,
            array(
                'id' => $notification_id,
                'user_id' => $user_id
            ),
            array('%d', '%d')
        );
        
        if ($result) {
            wp_send_json_success(__('Notification deleted', 'woodash-pro'));
        } else {
            wp_send_json_error(__('Failed to delete notification', 'woodash-pro'));
        }
    }
    
    /**
     * Clear all notifications
     */
    public function ajax_clear_all_notifications() {
        check_ajax_referer('woodash_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'woodash-pro'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'woodash_notifications';
        $user_id = get_current_user_id();
        
        $result = $wpdb->delete(
            $table_name,
            array('user_id' => $user_id),
            array('%d')
        );
        
        wp_send_json_success(sprintf(__('%d notifications cleared', 'woodash-pro'), $result));
    }
    
    /**
     * Save notification settings
     */
    public function ajax_save_notification_settings() {
        check_ajax_referer('woodash_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'woodash-pro'));
        }
        
        $settings = isset($_POST['settings']) ? $_POST['settings'] : array();
        $user_id = get_current_user_id();
        
        // Validate settings
        $default_settings = array(
            'soundEnabled' => true,
            'desktopEnabled' => true,
            'emailDigest' => true,
            'categories' => array(
                'order' => true,
                'alert' => true,
                'review' => true,
                'system' => true,
                'marketing' => false
            )
        );
        
        $settings = wp_parse_args($settings, $default_settings);
        
        update_user_meta($user_id, 'woodash_notification_settings', $settings);
        
        wp_send_json_success(__('Notification settings saved', 'woodash-pro'));
    }
    
    /**
     * Get notification settings
     */
    public function ajax_get_notification_settings() {
        check_ajax_referer('woodash_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'woodash-pro'));
        }
        
        $user_id = get_current_user_id();
        $settings = get_user_meta($user_id, 'woodash_notification_settings', true);
        
        $default_settings = array(
            'soundEnabled' => true,
            'desktopEnabled' => true,
            'emailDigest' => true,
            'categories' => array(
                'order' => true,
                'alert' => true,
                'review' => true,
                'system' => true,
                'marketing' => false
            )
        );
        
        if (!$settings) {
            $settings = $default_settings;
        } else {
            $settings = wp_parse_args($settings, $default_settings);
        }
        
        wp_send_json_success($settings);
    }
    
    /**
     * Add notification to database
     */
    public function add_notification($user_id, $type, $title, $message, $options = array()) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'woodash_notifications';
        
        $defaults = array(
            'priority' => 'medium',
            'icon' => 'fa-bell',
            'color' => '#3B82F6',
            'bg_color' => '#3B82F6',
            'actions' => array(),
            'metadata' => array()
        );
        
        $options = wp_parse_args($options, $defaults);
        
        $result = $wpdb->insert(
            $table_name,
            array(
                'user_id' => $user_id,
                'type' => $type,
                'priority' => $options['priority'],
                'title' => $title,
                'message' => $message,
                'icon' => $options['icon'],
                'color' => $options['color'],
                'bg_color' => $options['bg_color'],
                'actions' => json_encode($options['actions']),
                'metadata' => json_encode($options['metadata']),
                'is_read' => 0,
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s')
        );
        
        if ($result) {
            // Send real-time notification if user is online
            $this->send_realtime_notification($user_id, array(
                'id' => $wpdb->insert_id,
                'type' => $type,
                'priority' => $options['priority'],
                'title' => $title,
                'message' => $message,
                'icon' => $options['icon'],
                'color' => $options['color'],
                'bgColor' => $options['bg_color'],
                'actions' => $options['actions'],
                'metadata' => $options['metadata'],
                'time' => current_time('mysql'),
                'unread' => true,
                'sound' => $options['priority'] === 'high'
            ));
        }
        
        return $result;
    }
    
    /**
     * Send real-time notification to user
     */
    private function send_realtime_notification($user_id, $notification) {
        // This could be enhanced with WebSockets, Server-Sent Events, or polling
        // For now, we'll use WordPress transients for simple real-time updates
        $transient_key = 'woodash_realtime_notifications_' . $user_id;
        $existing_notifications = get_transient($transient_key) ?: array();
        
        $existing_notifications[] = $notification;
        
        // Keep only the last 10 real-time notifications
        if (count($existing_notifications) > 10) {
            $existing_notifications = array_slice($existing_notifications, -10);
        }
        
        set_transient($transient_key, $existing_notifications, 300); // 5 minutes
    }
    
    /**
     * Handle new order notification
     */
    public function handle_new_order_notification($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;
        
        $users = get_users(array('role' => 'administrator'));
        
        foreach ($users as $user) {
            $this->add_notification(
                $user->ID,
                'order',
                __('New Order Received', 'woodash-pro'),
                sprintf(__('Order #%s from %s - %s', 'woodash-pro'), 
                    $order->get_order_number(),
                    $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    $order->get_formatted_order_total()
                ),
                array(
                    'priority' => 'high',
                    'icon' => 'fa-shopping-cart',
                    'color' => '#10B981',
                    'bg_color' => '#10B981',
                    'actions' => array(
                        array('label' => __('View Order', 'woodash-pro'), 'action' => 'viewOrder', 'primary' => true),
                        array('label' => __('Process', 'woodash-pro'), 'action' => 'processOrder', 'primary' => false)
                    ),
                    'metadata' => array('order_id' => $order_id)
                )
            );
        }
    }
    
    /**
     * Handle order status change notification
     */
    public function handle_order_status_notification($order_id, $old_status, $new_status, $order) {
        if ($new_status === 'completed' || $new_status === 'processing') {
            $users = get_users(array('role' => 'administrator'));
            
            $title = sprintf(__('Order %s', 'woodash-pro'), ucfirst($new_status));
            $message = sprintf(__('Order #%s status changed to %s', 'woodash-pro'), 
                $order->get_order_number(), 
                ucfirst($new_status)
            );
            
            foreach ($users as $user) {
                $this->add_notification(
                    $user->ID,
                    'order',
                    $title,
                    $message,
                    array(
                        'priority' => 'medium',
                        'icon' => 'fa-truck',
                        'color' => '#3B82F6',
                        'bg_color' => '#3B82F6',
                        'actions' => array(
                            array('label' => __('View Order', 'woodash-pro'), 'action' => 'viewOrder', 'primary' => true)
                        ),
                        'metadata' => array('order_id' => $order_id, 'status' => $new_status)
                    )
                );
            }
        }
    }
    
    /**
     * Handle low stock notification
     */
    public function handle_low_stock_notification($product) {
        $users = get_users(array('role' => 'administrator'));
        
        foreach ($users as $user) {
            $this->add_notification(
                $user->ID,
                'alert',
                __('Low Stock Alert', 'woodash-pro'),
                sprintf(__('%s is running low on stock - Only %d items left', 'woodash-pro'), 
                    $product->get_name(),
                    $product->get_stock_quantity()
                ),
                array(
                    'priority' => 'medium',
                    'icon' => 'fa-exclamation-triangle',
                    'color' => '#F59E0B',
                    'bg_color' => '#F59E0B',
                    'actions' => array(
                        array('label' => __('Restock', 'woodash-pro'), 'action' => 'restock', 'primary' => true),
                        array('label' => __('View Product', 'woodash-pro'), 'action' => 'viewProduct', 'primary' => false)
                    ),
                    'metadata' => array('product_id' => $product->get_id())
                )
            );
        }
    }
    
    /**
     * Handle no stock notification
     */
    public function handle_no_stock_notification($product) {
        $users = get_users(array('role' => 'administrator'));
        
        foreach ($users as $user) {
            $this->add_notification(
                $user->ID,
                'alert',
                __('Out of Stock Alert', 'woodash-pro'),
                sprintf(__('%s is now out of stock', 'woodash-pro'), $product->get_name()),
                array(
                    'priority' => 'high',
                    'icon' => 'fa-times-circle',
                    'color' => '#EF4444',
                    'bg_color' => '#EF4444',
                    'actions' => array(
                        array('label' => __('Restock', 'woodash-pro'), 'action' => 'restock', 'primary' => true),
                        array('label' => __('View Product', 'woodash-pro'), 'action' => 'viewProduct', 'primary' => false)
                    ),
                    'metadata' => array('product_id' => $product->get_id())
                )
            );
        }
    }
    
    /**
     * Handle new review notification
     */
    public function handle_new_review_notification($comment_id, $comment_approved, $commentdata) {
        if ($comment_approved === 1 && $commentdata['comment_type'] === 'review') {
            $product_id = $commentdata['comment_post_ID'];
            $product = wc_get_product($product_id);
            
            if ($product) {
                $users = get_users(array('role' => 'administrator'));
                $rating = get_comment_meta($comment_id, 'rating', true);
                $stars = str_repeat('⭐', intval($rating));
                
                foreach ($users as $user) {
                    $this->add_notification(
                        $user->ID,
                        'review',
                        __('New Customer Review', 'woodash-pro'),
                        sprintf(__('%s "%s" - %s', 'woodash-pro'), 
                            $stars,
                            wp_trim_words($commentdata['comment_content'], 10),
                            $commentdata['comment_author']
                        ),
                        array(
                            'priority' => 'low',
                            'icon' => 'fa-star',
                            'color' => '#3B82F6',
                            'bg_color' => '#3B82F6',
                            'actions' => array(
                                array('label' => __('View Review', 'woodash-pro'), 'action' => 'viewReview', 'primary' => true),
                                array('label' => __('Reply', 'woodash-pro'), 'action' => 'replyReview', 'primary' => false)
                            ),
                            'metadata' => array('comment_id' => $comment_id, 'product_id' => $product_id)
                        )
                    );
                }
            }
        }
    }
    
    /**
     * Handle login notification (security)
     */
    public function handle_login_notification($user_login, $user) {
        // Check if login is from unusual location (simple IP check)
        $current_ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $last_ip = get_user_meta($user->ID, 'last_login_ip', true);
        
        if ($last_ip && $last_ip !== $current_ip) {
            $this->add_notification(
                $user->ID,
                'system',
                __('New Login Detected', 'woodash-pro'),
                sprintf(__('Login from new IP address: %s', 'woodash-pro'), $current_ip),
                array(
                    'priority' => 'medium',
                    'icon' => 'fa-sign-in-alt',
                    'color' => '#F59E0B',
                    'bg_color' => '#F59E0B',
                    'actions' => array(
                        array('label' => __('Review Activity', 'woodash-pro'), 'action' => 'reviewActivity', 'primary' => true),
                        array('label' => __('Secure Account', 'woodash-pro'), 'action' => 'secureAccount', 'primary' => false)
                    ),
                    'metadata' => array('ip' => $current_ip, 'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '')
                )
            );
        }
        
        update_user_meta($user->ID, 'last_login_ip', $current_ip);
        update_user_meta($user->ID, 'last_login_time', current_time('mysql'));
    }
    
    /**
     * Handle failed login notification
     */
    public function handle_failed_login_notification($username) {
        $users = get_users(array('role' => 'administrator'));
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        
        foreach ($users as $user) {
            $this->add_notification(
                $user->ID,
                'system',
                __('Failed Login Attempt', 'woodash-pro'),
                sprintf(__('Failed login attempt for "%s" from IP: %s', 'woodash-pro'), $username, $ip),
                array(
                    'priority' => 'high',
                    'icon' => 'fa-shield-alt',
                    'color' => '#EF4444',
                    'bg_color' => '#EF4444',
                    'actions' => array(
                        array('label' => __('Review Security', 'woodash-pro'), 'action' => 'reviewSecurity', 'primary' => true),
                        array('label' => __('Block IP', 'woodash-pro'), 'action' => 'blockIP', 'primary' => false)
                    ),
                    'metadata' => array('username' => $username, 'ip' => $ip, 'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '')
                )
            );
        }
    }
    
    /**
     * Create test notification (for development)
     */
    public function ajax_create_test_notification() {
        check_ajax_referer('woodash_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'woodash-pro'));
        }
        
        $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : 'order';
        $user_id = get_current_user_id();
        
        $test_notifications = array(
            'order' => array(
                'title' => 'New Test Order',
                'message' => 'Test order #WD-TEST-' . rand(1000, 9999) . ' from Test Customer - $' . rand(50, 500) . '.99',
                'options' => array(
                    'priority' => 'high',
                    'icon' => 'fa-shopping-cart',
                    'color' => '#10B981',
                    'bg_color' => '#10B981',
                    'actions' => array(
                        array('label' => 'View Order', 'action' => 'viewOrder', 'primary' => true),
                        array('label' => 'Process', 'action' => 'processOrder', 'primary' => false)
                    )
                )
            ),
            'alert' => array(
                'title' => 'Test Stock Alert',
                'message' => 'Test Product is running low on stock - Only ' . rand(1, 5) . ' items left',
                'options' => array(
                    'priority' => 'medium',
                    'icon' => 'fa-exclamation-triangle',
                    'color' => '#F59E0B',
                    'bg_color' => '#F59E0B',
                    'actions' => array(
                        array('label' => 'Restock', 'action' => 'restock', 'primary' => true),
                        array('label' => 'View Product', 'action' => 'viewProduct', 'primary' => false)
                    )
                )
            ),
            'review' => array(
                'title' => 'New Test Review',
                'message' => '⭐⭐⭐⭐⭐ "Great test product!" - Test Customer',
                'options' => array(
                    'priority' => 'low',
                    'icon' => 'fa-star',
                    'color' => '#3B82F6',
                    'bg_color' => '#3B82F6',
                    'actions' => array(
                        array('label' => 'View Review', 'action' => 'viewReview', 'primary' => true),
                        array('label' => 'Reply', 'action' => 'replyReview', 'primary' => false)
                    )
                )
            ),
            'system' => array(
                'title' => 'Test Security Alert',
                'message' => 'Test security event detected from IP: ' . ($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'),
                'options' => array(
                    'priority' => 'high',
                    'icon' => 'fa-shield-alt',
                    'color' => '#EF4444',
                    'bg_color' => '#EF4444',
                    'actions' => array(
                        array('label' => 'Review Security', 'action' => 'reviewSecurity', 'primary' => true),
                        array('label' => 'Secure Account', 'action' => 'secureAccount', 'primary' => false)
                    )
                )
            )
        );
        
        if (isset($test_notifications[$type])) {
            $notification = $test_notifications[$type];
            $result = $this->add_notification(
                $user_id,
                $type,
                $notification['title'],
                $notification['message'],
                $notification['options']
            );
            
            if ($result) {
                wp_send_json_success(__('Test notification created successfully', 'woodash-pro'));
            } else {
                wp_send_json_error(__('Failed to create test notification', 'woodash-pro'));
            }
        } else {
            wp_send_json_error(__('Invalid notification type', 'woodash-pro'));
        }
    }
    
    /**
     * AJAX handler for adding products
     */
    public function ajax_add_product() {
        if (!current_user_can('manage_woocommerce') || !wp_verify_nonce($_POST['nonce'], 'woodash_nonce')) {
            wp_send_json_error('Unauthorized');
        }

        $product_name = sanitize_text_field($_POST['product_name'] ?? '');
        $product_price = floatval($_POST['product_price'] ?? 0);
        $product_category = sanitize_text_field($_POST['product_category'] ?? '');
        $product_stock = intval($_POST['product_stock'] ?? 0);
        
        if (empty($product_name)) {
            wp_send_json_error('Product name is required');
        }
        
        try {
            $product = new WC_Product_Simple();
            $product->set_name($product_name);
            $product->set_regular_price($product_price);
            $product->set_manage_stock(true);
            $product->set_stock_quantity($product_stock);
            $product->set_stock_status($product_stock > 0 ? 'instock' : 'outofstock');
            $product->set_status('publish');
            
            if (!empty($product_category)) {
                // Create or get category
                $category = get_term_by('name', $product_category, 'product_cat');
                if (!$category) {
                    $category_result = wp_insert_term($product_category, 'product_cat');
                    if (!is_wp_error($category_result)) {
                        $category_id = $category_result['term_id'];
                    }
                } else {
                    $category_id = $category->term_id;
                }
                
                if (isset($category_id)) {
                    $product->set_category_ids(array($category_id));
                }
            }
            
            $product_id = $product->save();
            
            if ($product_id) {
                wp_send_json_success(array(
                    'message' => 'Product added successfully',
                    'product_id' => $product_id,
                    'product_name' => $product_name
                ));
            } else {
                wp_send_json_error('Failed to save product');
            }
        } catch (Exception $e) {
            wp_send_json_error('Error: ' . $e->getMessage());
        }
    }
    
    /**
     * AJAX handler for adding customers
     */
    public function ajax_add_customer() {
        if (!current_user_can('manage_woocommerce') || !wp_verify_nonce($_POST['nonce'], 'woodash_nonce')) {
            wp_send_json_error('Unauthorized');
        }

        $customer_name = sanitize_text_field($_POST['customer_name'] ?? '');
        $customer_email = sanitize_email($_POST['customer_email'] ?? '');
        $customer_phone = sanitize_text_field($_POST['customer_phone'] ?? '');
        
        if (empty($customer_name) || empty($customer_email)) {
            wp_send_json_error('Customer name and email are required');
        }
        
        if (!is_email($customer_email)) {
            wp_send_json_error('Invalid email address');
        }
        
        // Check if email already exists
        if (email_exists($customer_email)) {
            wp_send_json_error('Email already exists');
        }
        
        try {
            $customer = new WC_Customer();
            $customer->set_first_name($customer_name);
            $customer->set_email($customer_email);
            $customer->set_billing_phone($customer_phone);
            $customer->set_billing_email($customer_email);
            
            $customer_id = $customer->save();
            
            if ($customer_id) {
                wp_send_json_success(array(
                    'message' => 'Customer added successfully',
                    'customer_id' => $customer_id,
                    'customer_name' => $customer_name
                ));
            } else {
                wp_send_json_error('Failed to save customer');
            }
        } catch (Exception $e) {
            wp_send_json_error('Error: ' . $e->getMessage());
        }
    }
    
    /**
     * AJAX handler for adding orders
     */
    public function ajax_add_order() {
        if (!current_user_can('manage_woocommerce') || !wp_verify_nonce($_POST['nonce'], 'woodash_nonce')) {
            wp_send_json_error('Unauthorized');
        }

        $customer_id = intval($_POST['customer_id'] ?? 0);
        $product_id = intval($_POST['product_id'] ?? 0);
        $quantity = intval($_POST['quantity'] ?? 1);
        
        if ($product_id === 0) {
            wp_send_json_error('Product is required');
        }
        
        $product = wc_get_product($product_id);
        if (!$product) {
            wp_send_json_error('Invalid product');
        }
        
        try {
            $order = wc_create_order();
            
            if ($customer_id > 0) {
                $customer = new WC_Customer($customer_id);
                if ($customer->get_id()) {
                    $order->set_customer_id($customer_id);
                    $order->set_billing_first_name($customer->get_first_name());
                    $order->set_billing_email($customer->get_email());
                    $order->set_billing_phone($customer->get_billing_phone());
                }
            }
            
            $order->add_product($product, $quantity);
            $order->set_status('processing');
            $order->calculate_totals();
            $order->save();
            
            if ($order->get_id()) {
                wp_send_json_success(array(
                    'message' => 'Order created successfully',
                    'order_id' => $order->get_id(),
                    'order_total' => $order->get_total()
                ));
            } else {
                wp_send_json_error('Failed to create order');
            }
        } catch (Exception $e) {
            wp_send_json_error('Error: ' . $e->getMessage());
        }
    }
    
    /**
     * AJAX handler for adding coupons
     */
    public function ajax_add_coupon() {
        if (!current_user_can('manage_woocommerce') || !wp_verify_nonce($_POST['nonce'], 'woodash_nonce')) {
            wp_send_json_error('Unauthorized');
        }

        $coupon_code = sanitize_text_field($_POST['coupon_code'] ?? '');
        $coupon_amount = floatval($_POST['coupon_amount'] ?? 0);
        $coupon_type = sanitize_text_field($_POST['coupon_type'] ?? 'fixed_cart');
        
        if (empty($coupon_code)) {
            wp_send_json_error('Coupon code is required');
        }
        
        if ($coupon_amount <= 0) {
            wp_send_json_error('Coupon amount must be greater than 0');
        }
        
        // Check if coupon already exists
        $existing_coupon = new WC_Coupon($coupon_code);
        if ($existing_coupon->get_id()) {
            wp_send_json_error('Coupon code already exists');
        }
        
        try {
            $coupon = new WC_Coupon();
            $coupon->set_code($coupon_code);
            $coupon->set_amount($coupon_amount);
            $coupon->set_discount_type($coupon_type);
            $coupon->set_usage_limit(100); // Default usage limit
            $coupon->set_individual_use(false);
            $coupon->set_exclude_sale_items(false);
            
            $coupon_id = $coupon->save();
            
            if ($coupon_id) {
                wp_send_json_success(array(
                    'message' => 'Coupon created successfully',
                    'coupon_id' => $coupon_id,
                    'coupon_code' => $coupon_code
                ));
            } else {
                wp_send_json_error('Failed to create coupon');
            }
        } catch (Exception $e) {
            wp_send_json_error('Error: ' . $e->getMessage());
        }
    }
    
    /**
     * AJAX handler for getting marketing statistics
     */
    public function ajax_get_marketing_stats() {
        // Clean any output that might have been generated
        if (ob_get_level()) {
            ob_clean();
        }
        
        // Set proper headers
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=utf-8');
        }
        
        // Check nonce first
        if (!check_ajax_referer('woodash_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => 'Invalid nonce'));
            wp_die();
        }
        
        // Check user permissions
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => 'Unauthorized access'));
            wp_die();
        }

        global $wpdb;
        
        try {
            // Get campaign statistics
            $campaigns_table = $wpdb->prefix . 'woodash_campaigns';
            
            // Check if table exists
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$campaigns_table'");
            if (!$table_exists) {
                wp_send_json_error(array('message' => 'Campaigns table not found'));
                wp_die();
            }
            
            // Check for database errors
            if ($wpdb->last_error) {
                error_log('WooDash DB Error: ' . $wpdb->last_error);
                wp_send_json_error(array('message' => 'Database connection error'));
                wp_die();
            }
            
            $total_campaigns = $wpdb->get_var("SELECT COUNT(*) FROM $campaigns_table");
            $active_campaigns = $wpdb->get_var("SELECT COUNT(*) FROM $campaigns_table WHERE status = 'active'");
            $total_clicks = $wpdb->get_var("SELECT SUM(clicks) FROM $campaigns_table") ?: 0;
            $total_conversions = $wpdb->get_var("SELECT SUM(conversions) FROM $campaigns_table") ?: 0;
            $total_revenue = $wpdb->get_var("SELECT SUM(revenue) FROM $campaigns_table") ?: 0;
            
            // Email marketing stats
            $email_campaigns = $wpdb->get_var("SELECT COUNT(*) FROM $campaigns_table WHERE type = 'email'");
            $total_opens = $wpdb->get_var("SELECT SUM(opens) FROM $campaigns_table WHERE type = 'email'") ?: 0;
            $total_sends = $total_opens > 0 ? $total_opens * 4 : 1000; // Estimate
            
            $open_rate = $total_sends > 0 ? round(($total_opens / $total_sends) * 100, 1) : 24.5;
            $click_rate = $total_opens > 0 ? round(($total_clicks / $total_opens) * 100, 1) : 4.2;
            
            // Prepare response data
            $response_data = array(
                'total_campaigns' => intval($total_campaigns),
                'active_campaigns' => intval($active_campaigns),
                'total_clicks' => intval($total_clicks),
                'total_conversions' => intval($total_conversions),
                'total_revenue' => floatval($total_revenue),
                'email_stats' => array(
                    'subscribers' => 12456, // This would come from email service
                    'open_rate' => $open_rate,
                    'click_rate' => $click_rate,
                    'unsubscribe_rate' => 1.8
                )
            );
            
            wp_send_json_success($response_data);
            wp_die();
            
        } catch (Exception $e) {
            error_log('WooDash Marketing Stats Error: ' . $e->getMessage());
            wp_send_json_error(array('message' => 'Database error: ' . $e->getMessage()));
            wp_die();
        } catch (Error $e) {
            error_log('WooDash Marketing Stats Fatal Error: ' . $e->getMessage());
            wp_send_json_error(array('message' => 'Fatal error occurred'));
            wp_die();
        }
    }
    
    /**
     * AJAX handler for getting campaigns
     */
    public function ajax_get_campaigns() {
        // Check nonce first
        if (!check_ajax_referer('woodash_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => 'Invalid nonce'));
            return;
        }
        
        // Check user permissions
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => 'Unauthorized access'));
            return;
        }

        global $wpdb;
        $campaigns_table = $wpdb->prefix . 'woodash_campaigns';
        
        try {
            // Check if table exists
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$campaigns_table'");
            if (!$table_exists) {
                wp_send_json_error(array('message' => 'Campaigns table not found'));
                return;
            }
            
            $page = intval($_POST['page'] ?? 1);
            $per_page = intval($_POST['per_page'] ?? 10);
            $offset = ($page - 1) * $per_page;
            
            $campaigns = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $campaigns_table ORDER BY created_at DESC LIMIT %d OFFSET %d",
                $per_page,
                $offset
            ));
            
            $total_campaigns = $wpdb->get_var("SELECT COUNT(*) FROM $campaigns_table");
            
            wp_send_json_success(array(
                'campaigns' => $campaigns ?: array(),
                'total' => intval($total_campaigns),
                'page' => $page,
                'per_page' => $per_page,
                'total_pages' => $total_campaigns > 0 ? ceil($total_campaigns / $per_page) : 1
            ));
        } catch (Exception $e) {
            error_log('WooDash Campaigns Error: ' . $e->getMessage());
            wp_send_json_error(array('message' => 'Database error: ' . $e->getMessage()));
        }
    }
    
    /**
     * AJAX handler for creating campaigns
     */
    public function ajax_create_campaign() {
        if (!current_user_can('manage_woocommerce') || !wp_verify_nonce($_POST['nonce'], 'woodash_nonce')) {
            wp_send_json_error('Unauthorized');
        }

        global $wpdb;
        $campaigns_table = $wpdb->prefix . 'woodash_campaigns';
        
        $name = sanitize_text_field($_POST['name'] ?? '');
        $type = sanitize_text_field($_POST['type'] ?? 'email');
        $subject = sanitize_text_field($_POST['subject'] ?? '');
        $content = wp_kses_post($_POST['content'] ?? '');
        $status = sanitize_text_field($_POST['status'] ?? 'draft');
        
        if (empty($name)) {
            wp_send_json_error('Campaign name is required');
        }
        
        try {
            $result = $wpdb->insert(
                $campaigns_table,
                array(
                    'name' => $name,
                    'type' => $type,
                    'subject' => $subject,
                    'content' => $content,
                    'status' => $status,
                    'created_at' => current_time('mysql')
                ),
                array('%s', '%s', '%s', '%s', '%s', '%s')
            );
            
            if ($result) {
                $campaign_id = $wpdb->insert_id;
                wp_send_json_success(array(
                    'message' => 'Campaign created successfully',
                    'campaign_id' => $campaign_id,
                    'campaign' => array(
                        'id' => $campaign_id,
                        'name' => $name,
                        'type' => $type,
                        'status' => $status
                    )
                ));
            } else {
                wp_send_json_error('Failed to create campaign');
            }
        } catch (Exception $e) {
            wp_send_json_error('Error: ' . $e->getMessage());
        }
    }
    
    /**
     * AJAX handler for updating campaigns
     */
    public function ajax_update_campaign() {
        if (!current_user_can('manage_woocommerce') || !wp_verify_nonce($_POST['nonce'], 'woodash_nonce')) {
            wp_send_json_error('Unauthorized');
        }

        global $wpdb;
        $campaigns_table = $wpdb->prefix . 'woodash_campaigns';
        
        $campaign_id = intval($_POST['campaign_id'] ?? 0);
        $name = sanitize_text_field($_POST['name'] ?? '');
        $type = sanitize_text_field($_POST['type'] ?? 'email');
        $subject = sanitize_text_field($_POST['subject'] ?? '');
        $content = wp_kses_post($_POST['content'] ?? '');
        $status = sanitize_text_field($_POST['status'] ?? 'draft');
        
        if ($campaign_id === 0) {
            wp_send_json_error('Campaign ID is required');
        }
        
        try {
            $result = $wpdb->update(
                $campaigns_table,
                array(
                    'name' => $name,
                    'type' => $type,
                    'subject' => $subject,
                    'content' => $content,
                    'status' => $status,
                    'updated_at' => current_time('mysql')
                ),
                array('id' => $campaign_id),
                array('%s', '%s', '%s', '%s', '%s', '%s'),
                array('%d')
            );
            
            if ($result !== false) {
                wp_send_json_success(array(
                    'message' => 'Campaign updated successfully',
                    'campaign_id' => $campaign_id
                ));
            } else {
                wp_send_json_error('Failed to update campaign');
            }
        } catch (Exception $e) {
            wp_send_json_error('Error: ' . $e->getMessage());
        }
    }
    
    /**
     * AJAX handler for deleting campaigns
     */
    public function ajax_delete_campaign() {
        if (!current_user_can('manage_woocommerce') || !wp_verify_nonce($_POST['nonce'], 'woodash_nonce')) {
            wp_send_json_error('Unauthorized');
        }

        global $wpdb;
        $campaigns_table = $wpdb->prefix . 'woodash_campaigns';
        
        $campaign_id = intval($_POST['campaign_id'] ?? 0);
        
        if ($campaign_id === 0) {
            wp_send_json_error('Campaign ID is required');
        }
        
        try {
            // Check if campaign exists
            $campaign = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $campaigns_table WHERE id = %d",
                $campaign_id
            ));
            
            if (!$campaign) {
                wp_send_json_error('Campaign not found');
            }
            
            $result = $wpdb->delete(
                $campaigns_table,
                array('id' => $campaign_id),
                array('%d')
            );
            
            if ($result) {
                wp_send_json_success(array(
                    'message' => 'Campaign deleted successfully',
                    'campaign_id' => $campaign_id
                ));
            } else {
                wp_send_json_error('Failed to delete campaign');
            }
        } catch (Exception $e) {
            wp_send_json_error('Error: ' . $e->getMessage());
        }
    }
}

// Initialize the plugin
WoodashPro::get_instance();

// Declare WooCommerce HPOS compatibility
add_action('before_woocommerce_init', function() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});
