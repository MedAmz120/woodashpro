<?php
// If this file is called directly, abort.
if (!defined('WPINC')) {
	die;
}

// Check if user has required capabilities
if (!current_user_can('manage_woocommerce')) {
	wp_die(__('You do not have sufficient permissions to access this page.', 'woodashh'));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Customers Dashboard</title>
    <link href="https://fonts.googleapis.com/css?family=Inter:400,500,600,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

	<style>
		/* Enhanced, modern, soft style */
		body {
			background: #f3f4f6;
		}
		.woodash-card {
			background: #fff;
			border-radius: 1.25rem;
			box-shadow: 0 4px 24px 0 rgba(0,0,0,0.07), 0 1.5px 4px 0 rgba(0,0,0,0.03);
			border: none;
			transition: box-shadow 0.2s, transform 0.2s;
		}
		.woodash-card:hover {
			box-shadow: 0 8px 32px 0 rgba(0,204,97,0.10), 0 2px 8px 0 rgba(0,0,0,0.04);
			transform: translateY(-2px) scale(1.01);
		}
		.customer-avatar {
			width: 2.5rem;
			height: 2.5rem;
			border-radius: 9999px;
			background: linear-gradient(135deg, #00CC61 60%, #00b357 100%);
			color: #fff;
			display: flex;
			align-items: center;
			justify-content: center;
			font-weight: 600;
			font-size: 1rem;
			margin-right: 0.75rem;
			box-shadow: 0 2px 8px 0 rgba(0,204,97,0.10);
		}
		.customer-badge {
			display: inline-block;
			padding: 0.25rem 0.75rem;
			border-radius: 9999px;
			font-size: 0.75rem;
			font-weight: 500;
			background: #e0f7ef;
			color: #00b357;
			margin-left: 0.5rem;
			letter-spacing: 0.01em;
		}
		.woodash-table-header {
			background: #f8fafc;
			font-size: 1rem;
			letter-spacing: 0.01em;
			color: #374151;
		}
		.woodash-table-row {
			transition: background 0.2s, box-shadow 0.2s;
		}
		.woodash-table-row:hover {
			background: #e6f9f0;
			box-shadow: 0 2px 8px 0 rgba(0,204,97,0.07);
		}
		.woodash-search-bar {
			display: flex;
			align-items: center;
			gap: 0.5rem;
			background: #fff;
			border: 1.5px solid #e5e7eb;
			border-radius: 0.75rem;
			padding: 0.5rem 1rem;
			margin-bottom: 1.5rem;
			box-shadow: 0 1.5px 4px 0 rgba(0,0,0,0.04);
			max-width: 350px;
		}
		.woodash-search-bar input {
			border: none;
			outline: none;
			background: transparent;
			width: 100%;
			font-size: 1rem;
			color: #374151;
		}
		.woodash-btn-secondary {
			background: #f3f4f6;
			color: #00b357;
			border: 1.5px solid #e5e7eb;
		}
		.woodash-btn-secondary:hover {
			background: #e0f7ef;
			color: #059669;
		}
		.woodash-gradient-text {
			background: linear-gradient(45deg, #00CC61, #00b357);
			-webkit-background-clip: text;
			-webkit-text-fill-color: transparent;
			background-clip: text;
		}
		.woodash-main h1 {
			font-size: 2.2rem;
			font-weight: 700;
			margin-bottom: 0.25rem;
		}
		.woodash-main p {
			color: #6b7280;
		}
		.woodash-card .text-3xl {
			font-size: 2.1rem;
			color: #00b357;
		}
		.woodash-card h3 {
			color: #6b7280;
		}
		@media (max-width: 640px) {
			.customer-avatar { width: 2rem; height: 2rem; font-size: 0.9rem; }
			.woodash-search-bar { max-width: 100%; }
			.woodash-main h1 { font-size: 1.3rem; }
		}
	</style>
</head>
<body class="bg-gray-100">
<button id="woodash-menu-toggle" class="woodash-menu-toggle fixed top-4 left-4 z-60 bg-white p-2 rounded-lg shadow-lg lg:hidden" aria-label="Open menu">
	<i class="fa-solid fa-bars text-xl text-[#00CC61]"></i>
</button>
<div id="woodash-sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-30 z-40 hidden lg:hidden"></div>
		.woodash-menu-toggle {
			display: none;
		}
		@media (max-width: 1024px) {
			.woodash-menu-toggle {
				display: block;
			}
			.woodash-sidebar {
				transform: translateX(-100%);
				transition: transform 0.3s ease;
			}
			.woodash-sidebar.active {
				transform: translateX(0);
			}
			#woodash-sidebar-overlay {
				display: block;
			}
		}
<div id="woodash-dashboard" class="min-h-screen w-full flex">
	<!-- Sidebar -->
    <aside class="woodash-sidebar w-64 bg-white/90 border-r border-gray-100 woodash-glass-effect flex flex-col justify-between">

	
		<div class="pt-10 pb-4 px-6">
			<div class="flex items-center gap-4 mb-10 woodash-fade-in">
				<div class="w-12 h-12 rounded-lg bg-gradient-to-br from-[#00CC61] to-[#00b357] flex items-center justify-center woodash-glow">
					<i class="fa-solid fa-users text-white text-2xl"></i>
				</div>
				<h2 class="text-2xl font-bold woodash-gradient-text ml-1">WooDash Pro</h2>
			</div>
			<!-- Main Navigation -->
			<nav class="flex flex-col gap-1 mt-2">
				<a href="<?php echo esc_url(admin_url('admin.php?page=woodash-pro')); ?>" class="woodash-nav-link flex items-center gap-4 px-4 py-2 rounded-lg hover:bg-[#f3f4f6] transition">
					<i class="fa-solid fa-gauge w-5"></i>
					<span>Dashboard</span>
				</a>
				<a href="<?php echo esc_url(admin_url('admin.php?page=woodash-pro-orders')); ?>" class="woodash-nav-link flex items-center gap-4 px-4 py-2 rounded-lg hover:bg-[#f3f4f6] transition">
					<i class="fa-solid fa-cart-shopping w-5"></i>
					<span>Orders</span>
				</a>
				<a href="<?php echo esc_url(admin_url('admin.php?page=woodash-pro-products')); ?>" class="woodash-nav-link flex items-center gap-4 px-4 py-2 rounded-lg hover:bg-[#f3f4f6] transition">
					<i class="fa-solid fa-box w-5"></i>
					<span>Products</span>
				</a>
				<a href="<?php echo esc_url(admin_url('admin.php?page=woodash-pro-customers')); ?>" class="woodash-nav-link active flex items-center gap-4 px-4 py-2 rounded-lg bg-[#e0f7ef] text-[#00b357] font-semibold">
					<i class="fa-solid fa-users w-5"></i>
					<span>Customers</span>
				</a>
				<a href="<?php echo esc_url(admin_url('admin.php?page=woodash-pro-stock')); ?>" class="woodash-nav-link flex items-center gap-4 px-4 py-2 rounded-lg hover:bg-[#f3f4f6] transition">
					<i class="fa-solid fa-boxes-stacked w-5"></i>
					<span>Stock</span>
				</a>
				<a href="<?php echo esc_url(admin_url('admin.php?page=woodash-pro-reviews')); ?>" class="woodash-nav-link flex items-center gap-4 px-4 py-2 rounded-lg hover:bg-[#f3f4f6] transition">
					<i class="fa-solid fa-star w-5"></i>
					<span>Reviews</span>
				</a>
				<a href="<?php echo esc_url(admin_url('admin.php?page=woodash-pro-marketing')); ?>" class="woodash-nav-link flex items-center gap-4 px-4 py-2 rounded-lg hover:bg-[#f3f4f6] transition">
					<i class="fa-solid fa-bullhorn w-5"></i>
					<span>Marketing</span>
				</a>
				<a href="<?php echo esc_url(admin_url('admin.php?page=woodash-pro-reports')); ?>" class="woodash-nav-link flex items-center gap-4 px-4 py-2 rounded-lg hover:bg-[#f3f4f6] transition">
					<i class="fa-solid fa-file-lines w-5"></i>
					<span>Reports</span>
				</a>
				<a href="<?php echo esc_url(admin_url('admin.php?page=woodash-pro-settings')); ?>" class="woodash-nav-link flex items-center gap-4 px-4 py-2 rounded-lg hover:bg-[#f3f4f6] transition">
					<i class="fa-solid fa-gear w-5"></i>
					<span>Settings</span>
				</a>
			</nav>
		</div>
		<!-- User Profile Section -->
		<div class="mt-8 px-6 pb-4">
			<div class="flex items-center gap-4 pt-4 border-t border-gray-100">
				<div class="w-11 h-11 rounded-full bg-gradient-to-br from-[#00CC61] to-[#00b357] flex items-center justify-center">
					<span class="text-white font-semibold text-lg">JD</span>
				</div>
				<div class="flex-1 min-w-0">
					<div class="font-medium text-gray-900 leading-tight">John Doe</div>
					<a href="#" class="text-sm text-[#00CC61] hover:underline woodash-logout-btn">Logout</a>
				</div>
				<button class="p-1 rounded-lg hover:bg-gray-100 transition-colors duration-200">
					<i class="fa-solid fa-ellipsis-vertical text-gray-400"></i>
				</button>
			</div>
		</div>
	</aside>

	<!-- Scroll to Top Button -->
	<button id="woodash-scroll-to-top" class="fixed bottom-6 right-6 woodash-btn woodash-btn-primary rounded-full w-12 h-12 flex items-center justify-center woodash-hover-card woodash-glow" style="display: none;">
		<i class="fa-solid fa-arrow-up"></i>
	</button>

	<!-- Main Content -->
	<main class="woodash-main flex-1 min-w-0 p-6 md:p-8 ml-0 lg:ml-64">
		<div class="max-w-7xl mx-auto">
			<!-- Header -->
			<header class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
				<div>
					<h1 class="text-2xl font-bold woodash-gradient-text">Customers</h1>
					<p class="text-gray-500">View and manage your customers.</p>
				</div>
			</header>

			<!-- Quick Stats -->
			<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
				<div class="woodash-card p-6">
					<div class="flex items-center justify-between">
						<div>
							<h3 class="text-sm font-medium text-gray-500 mb-1">Total Customers</h3>
							<div class="text-3xl font-bold text-gray-900" data-stat="total-customers">543</div>
						</div>
						<div class="w-10 h-10 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center">
							<i class="fa-solid fa-users"></i>
						</div>
					</div>
				</div>
				<div class="woodash-card p-6">
					<div class="flex items-center justify-between">
						<div>
							<h3 class="text-sm font-medium text-gray-500 mb-1">New Customers</h3>
							<div class="text-3xl font-bold text-gray-900" data-stat="new-customers">47</div>
						</div>
						<div class="w-10 h-10 rounded-full bg-green-100 text-green-600 flex items-center justify-center">
							<i class="fa-solid fa-user-plus"></i>
						</div>
					</div>
				</div>
				<div class="woodash-card p-6">
					<div class="flex items-center justify-between">
						<div>
							<h3 class="text-sm font-medium text-gray-500 mb-1">Returning Customers</h3>
							<div class="text-3xl font-bold text-gray-900">120</div>
						</div>
						<div class="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center">
							<i class="fa-solid fa-user-check"></i>
						</div>
					</div>
				</div>
				<div class="woodash-card p-6">
					<div class="flex items-center justify-between">
						<div>
							<h3 class="text-sm font-medium text-gray-500 mb-1">Customer LTV</h3>
							<div class="text-3xl font-bold text-gray-900">$1,250</div>
						</div>
						<div class="w-10 h-10 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center">
							<i class="fa-solid fa-coins"></i>
						</div>
					</div>
				</div>
			</div>

			<!-- Customers Table -->
			<div class="woodash-card p-6">
				<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-3">
					<h3 class="text-lg font-bold woodash-gradient-text">Customer List</h3>
					<div class="flex gap-2 w-full sm:w-auto">
						<form class="woodash-search-bar" onsubmit="return false;">
							<i class="fa fa-search text-gray-400"></i>
							<input id="customer-search" type="text" placeholder="Search customers..." autocomplete="off">
						</form>
						<button class="woodash-btn woodash-btn-secondary text-sm">
							<i class="fa fa-download mr-1"></i> Export CSV
						</button>
					</div>
				</div>
				<div class="overflow-x-auto">
					<table class="w-full">
						<thead class="woodash-table-header">
							<tr class="border-b border-gray-200">
								<th class="text-left py-3 px-4 font-medium text-gray-600">Name</th>
								<th class="text-left py-3 px-4 font-medium text-gray-600">Email</th>
								<th class="text-left py-3 px-4 font-medium text-gray-600">Orders</th>
								<th class="text-left py-3 px-4 font-medium text-gray-600">Total Spent</th>
								<th class="text-left py-3 px-4 font-medium text-gray-600">Joined</th>
								<th class="text-left py-3 px-4 font-medium text-gray-600">Status</th>
							</tr>
						</thead>
						<tbody id="customers-table">
							<!-- Customer data will be loaded here -->
						</tbody>
					</table>
				</div>
			</div>
		</div>

		<footer>
			<div class="max-w-7xl mx-auto text-center py-4 text-gray-600 text-sm">
				<p>&copy; <?php echo date('Y'); ?> WooDash Pro. All rights reserved.</p>
			</div>
		</footer>
	</main>
</div>


<script>
// WordPress AJAX Configuration
window.woodash_ajax = {
	ajax_url: '<?php echo esc_url(admin_url('admin-ajax.php')); ?>',
	nonce: '<?php echo wp_create_nonce('woodash_nonce'); ?>'
};

document.addEventListener('DOMContentLoaded', function() {
	// Mobile sidebar toggle
	const menuToggle = document.getElementById('woodash-menu-toggle');
	const sidebar = document.querySelector('.woodash-sidebar');
	const sidebarOverlay = document.getElementById('woodash-sidebar-overlay');
	if (menuToggle && sidebar) {
		menuToggle.addEventListener('click', function(e) {
			sidebar.classList.add('active');
			if (sidebarOverlay) sidebarOverlay.classList.remove('hidden');
		});
	}
	if (sidebarOverlay && sidebar) {
		sidebarOverlay.addEventListener('click', function() {
			sidebar.classList.remove('active');
			sidebarOverlay.classList.add('hidden');
		});
	}
	// Scroll to Top Button
	const scrollTopButton = document.getElementById('woodash-scroll-to-top');
	if (scrollTopButton) {
		window.addEventListener('scroll', () => {
			scrollTopButton.style.display = window.scrollY > 300 ? 'flex' : 'none';
		});
		scrollTopButton.addEventListener('click', () => {
			window.scrollTo({ top: 0, behavior: 'smooth' });
		});
	}

	// Mobile sidebar toggle (optional, if you add a menu button)
	// const menuToggle = document.getElementById('woodash-menu-toggle');
	// const sidebar = document.querySelector('.woodash-sidebar');
	// menuToggle?.addEventListener('click', () => {
	//     sidebar.classList.toggle('active');
	// });

	// Click outside to close sidebar on mobile (if implemented)
	// document.addEventListener('click', function(e) {
	//     if (window.innerWidth <= 768 && sidebar && !sidebar.contains(e.target) && !menuToggle.contains(e.target) && sidebar.classList.contains('active')) {
	//         sidebar.classList.remove('active');
	//     }
	// });

	const CustomersManager = {
		state: {
			customers: []
		},

		init() {
			this.loadCustomers();
		},

		async loadCustomers() {
			try {
				const formData = new FormData();
				formData.append('action', 'woodash_get_customers');
				formData.append('nonce', woodash_ajax.nonce);

				const response = await fetch(woodash_ajax.ajax_url, {
					method: 'POST',
					body: formData
				});

				const result = await response.json();
				if (result.success) {
					this.state.customers = result.data;
					this.renderCustomersTable(result.data);
				} else {
					this.loadDemoCustomers();
				}
			} catch (error) {
				this.loadDemoCustomers();
			}
		},

		renderCustomersTable(customers) {
			const tbody = document.getElementById('customers-table');
			if (!tbody) return;
			tbody.innerHTML = '';
			(customers || []).forEach(customer => {
				const row = document.createElement('tr');
				row.className = 'woodash-table-row border-b border-gray-200';
				// Avatar initials
				const initials = (customer.name || '').split(' ').map(n => n[0]).join('').substring(0,2).toUpperCase();
				// Status badge
				let status = 'Regular';
				let badge = '<span class="customer-badge">Regular</span>';
				if (customer.orders > 10) {
					status = 'VIP';
					badge = '<span class="customer-badge" style="background:#ECFDF5;color:#059669;">VIP</span>';
				} else if (customer.orders === 1) {
					status = 'New';
					badge = '<span class="customer-badge" style="background:#FDF6EC;color:#D97706;">New</span>';
				}
				row.innerHTML = `
					<td class="px-6 py-4 text-sm font-medium text-gray-900 flex items-center">
						<span class="customer-avatar">${initials}</span>
						<span>${customer.name}</span>
					</td>
					<td class="px-6 py-4 text-sm text-gray-900">${customer.email}</td>
					<td class="px-6 py-4 text-sm text-gray-900">${customer.orders}</td>
					<td class="px-6 py-4 text-sm text-gray-900">$${(customer.total_spent || 0).toFixed(2)}</td>
					<td class="px-6 py-4 text-sm text-gray-900">${customer.joined}</td>
					<td class="px-6 py-4 text-sm">${badge}</td>
				`;
				tbody.appendChild(row);
			});
		},
	// Search/filter functionality
	document.getElementById('customer-search').addEventListener('input', function(e) {
		const search = e.target.value.toLowerCase();
		const filtered = CustomersManager.state.customers.filter(c =>
			c.name.toLowerCase().includes(search) ||
			c.email.toLowerCase().includes(search)
		);
		CustomersManager.renderCustomersTable(filtered);
	});

		loadDemoCustomers() {
			this.renderCustomersTable([
				{ name: 'Jane Smith', email: 'jane@example.com', orders: 12, total_spent: 1500.75, joined: '2023-01-15' },
				{ name: 'Bob Johnson', email: 'bob@example.com', orders: 8, total_spent: 950.00, joined: '2022-11-03' },
				{ name: 'Alice Lee', email: 'alice@example.com', orders: 5, total_spent: 600.50, joined: '2024-03-22' }
			]);
		}
	};
	CustomersManager.init();
});
</script>

</body>
</html>
